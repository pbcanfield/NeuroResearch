#include <stdio.h>
#include "hocdec.h"
#define IMPORT extern __declspec(dllimport)
IMPORT int nrnmpi_myid, nrn_nobanner_;

extern void _h_reg();
extern void _kdrca1_reg();
extern void _leak_reg();
extern void _nat_reg();

void modl_reg(){
	//nrn_mswindll_stdio(stdin, stdout, stderr);
    if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," h.mod");
fprintf(stderr," kdrca1.mod");
fprintf(stderr," leak.mod");
fprintf(stderr," nat.mod");
fprintf(stderr, "\n");
    }
_h_reg();
_kdrca1_reg();
_leak_reg();
_nat_reg();
}
