%% load
con = importdata('Connections.txt');

%% run
close all;
locFiles = dir('Loc*.txt');
% col = ['mp'; 'mp'; 'r>'; 'go'; 'mp'; 'k>'; 'go' ];
col2 = {'mp'; 'kp'; 'r>'; 'go'; 'bp'; 'k>'; 'go' }; %using CELL ARRAYS as indicated by the curly braces!

for i = 1:size(locFiles)
       stg = locFiles(i).name;
       loc = importdata(stg);
        y{i} = loc ;     
% plot3(loc(:,1), loc(:,2), loc(:,3),  col(i, :), 'MarkerFaceColor', [0 1 0] )
H = plot3(loc(:,1), loc(:,2), loc(:,3),  col2{i});  %, 'MarkerFaceColor', [0 1 0] )
set(H,'ButtonDownFcn','disp(get(gca,''CurrentPoint'')); plotCon(y, get(gca, ''CurrentPoint''))');
hold on;
       
end

legend('EC', 'CA3 pyramidal', 'CA3 OLM', 'CA3 BC', 'DG granule', 'DG HIPP', 'DG BC');

y{1}(1,:)


for n = 1:size(con, 1)
   preArea = con(n,2);
   preId = con(n,3);
   postArea= con(n,4);
   postId = con(n,5);
   
   if (preId == 17 && preArea == 0)% && postArea == 4)
%     if (postId == 3 && postArea == 3)% && postArea == 4)
        preLoc = y{preArea +1}(preId+1,:);
        postLoc = y{postArea +1}(postId+1,:);
        lineLoc = [preLoc; postLoc];
       	line(lineLoc(:,1), lineLoc(:,2), lineLoc(:,3), 'LineWidth', 1)
    end
end