%% Read data
OutPath = '..\Outputs\';
con = importdata([OutPath '211Connections.txt']); 
weights = importdata([OutPath '211Weights.txt']);
currents = importdata([OutPath '211Currents.txt']);  
%% dom
close all;

from = 0; to = 12000;
gd.postArea = 8;
gd.postID = 0;
% con weights currents 

incoming = con (con(:,4) == gd.postArea & con(:,5) == gd.postID , :);

uniAreas = unique(incoming(:, 2));

for p = 1:size(uniAreas)
   areaSpecific = incoming(incoming(:,2) == uniAreas(p), :); 
   syn = struct();
   for i = 1:size(areaSpecific, 1)
    synSize = size(syn ,2);
    syn(synSize).ID =         areaSpecific(i, 1);
    syn(synSize).preArea =    areaSpecific(i, 2);
    syn(synSize).preID =      areaSpecific(i, 3);
    syn(synSize).postArea =   areaSpecific(i, 4);
    syn(synSize).postID =     areaSpecific(i, 5);
    syn(synSize).type =       areaSpecific(i, 6);
    syn(synSize).weight =     weights(2:end, (weights(1,:) == areaSpecific(i, 1)));
    syn(synSize).current =    currents(2:end, (currents(1,:) == areaSpecific(i, 1)));
       syn(synSize + 1).ID = 0;
   end
   syn(end) = []; %deletes this last struct with ID = 0
%    
%    TotalCount = size(syn.2); 
%    for k = 1:TotalCount
%         anyC = 
%    end
   csyn = syn;
fC= struct();
   chosen = [];
   for s = 1:size(syn, 2)
      pp = (abs(syn(s).current) > 0.001);
     %pp = sum(syn(s).current);
        fC(end+1).Log = pp;
      gain = syn(s).weight(end) - syn(s).weight(1);
      if (sum(pp) || (gain > 0.01))
         chosen (end+1) = syn(s).ID; 
      
      else
        for cs = 1:size(csyn, 2)
          if (csyn(cs).ID == syn(s).ID)
             csyn(cs) = [];
             break
          end
        end
      end
   end
   
   %selected = syn( syn.current > 0.01
   
   figure('Position', [0 200 * (p-1) 600 200]);

    plots = size(csyn, 2);
   % check if significant weight or current changes
   % plot specific times;
 
%    twvec2 = weights(2:end, 1);
%    twvec = twvec2(twvec2 >= from & twvec2 <= to);
   twvec = weights(2:end, 1);
   for j = 1:size(csyn, 2)
       subplot(1, plots, j);
       subplot('Position',[ 1/plots*(j-1)    0.0910    .8/plots    0.7])
       
       plot(twvec, csyn(j).weight); 
          title(num2str(csyn(j).ID));
         xlim([from to]); ylim([0 4]);
   end
   figure('Position', [700 200*(p-1) 600 200]);
   tcvec = currents(2:end,1);

   if (size(csyn, 2) > 0)
   plot(tcvec, [csyn.current] ); % this access ALL current fields and puts them into an array!!
    xlim([from to]);
    ymax = ylim;
    yy2 = ymax(2); yrange = ymax(2) - ymax(1);
    yyy = yy2 - (yrange / 6); 
    text(0, yyy,num2str(csyn(1).preArea));
            
        for leg = 1:size(csyn,2)
            legCA{leg} = num2str(csyn(leg).ID);
        end
   legend(legCA, 'Location', 'SouthWest');
    set(gca,'Position',[ 0.059    0.0910    0.9965    0.9935])
   else
       plot(tcvec, zeros(size(tcvec)));
           ymax = ylim;
    yy2 = ymax(2); yrange = ymax(2) - ymax(1);
    yyy = yy2 - (yrange / 8); 
    text(0, yyy, num2str(uniAreas(p)));
   end
 end