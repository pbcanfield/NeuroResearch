 close all
 ac20 = figure('Color',[1 1 1]);
  set(ac20, 'ToolBar', 'none');

set(ac20, 'Position', [100 200 700 400])
subx = 4; suby=2;
subplot(subx,suby,1)

%% MF
 currentData = importdata('FacilitationNewMF.dat');
% figure()
min_x = 0;
max_x = 240; %calculated duration 225 
min_y = -0.15563;
max_y = 0;


bio = imread('FacilitationMF.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;
title('Mossy fiber')

xdummy = [0];

% plot( currentData(cut:size(currentData,1), 1) , currentData(1:sc, 2) )
g = plot( currentData(:, 1), currentData(:, 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2);
% j = plot(xdummy, xdummy, 'k', 'LineWidth', 3)
% legend(g, 'Simulation', 'Recordings' , 'Location', 'SouthWest')
% legend boxoff

linn = line ([min_x min_x+50], [max_y-.05 max_y-.05], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(2, max_y-0.07 ,'50ms')

linn = line ([80 80], [-0.078 -0.143], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(85, -0.11,'100pA')

% legend(j, 'recording', 'Location', 'SouthWest')
% set the y-axis back to normal.
set(gca,'ydir','normal');
axis off

%% 20Hz
currentData = importdata('CA3ACVoltage20Hz.txt');

min_x = -0.7;
max_x = 499;
min_y = 73.9;
max_y = 75.25;
subplot(subx,suby,[7 8])
bio = imread('AC20Hz2.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;

cut = 001;

sc = size(currentData,1) - cut +1;

xdummy = [0];

tindex = find(currentData(:,1) < 500);
tvec= (currentData(tindex,1));
vvec = (currentData(tindex,2));
g = plot( currentData(1:sc, 1), -currentData(cut:size(currentData,1), 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2);

linn = line ([450 500], [74 74], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(460, 73.8,'50ms')

linn = line ([480 480], [74.0 74.5], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(490, 74.4,'0.5mv')

text(246, 73.7,'20Hz')

set(gca,'ydir','normal');
axis off

%% 50Hz
currentData = importdata('CA3AC.txt');
min_x = 1;
max_x = 209;
min_y = 73.7;
max_y = 75.4;
subplot(subx,suby, [5 6] ) %[7 9])
bio = imread('AC50Hz2.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;

linn = line ([185 205], [73.8 73.8], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(190, 73.55,'20ms')

linn = line ([200 200], [74.0 74.5], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(203, 74.3,'0.5mv')

text(103, 73.7,'50Hz')
cut = 001;

sc = size(currentData,1) - cut +1;

xdummy = [0];
 
tindex = find(currentData(:,1) < 200);
tvec= (currentData(tindex,1));
vvec = (currentData(tindex,2));
% plot( currentData(cut:size(currentData,1), 1) , currentData(1:sc, 2) )
g = plot( currentData(1:sc, 1), -currentData(cut:size(currentData,1), 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2);
% j = plot(xdummy, xdummy, 'k', 'LineWidth', 3)
% legend(g, 'Simulation', 'Recordings' , 'Location', 'SouthEast')
% legend boxoff
title('CA3 A/C recurrents')
% legend(j, 'recording', 'Location', 'SouthWest')
% set the y-axis back to normal.
set(gca,'ydir','normal');
axis off

%% Pyramical to BC
currentData = importdata('BC.txt');

min_x = 0;
max_x = 154.16; % calculated duration
min_y = -65.1;
max_y = -63.39; % height is 1.61 mv

subplot(subx,suby,2)
bio = imread('Pyr2BCDep.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;

xdummy = [0];

title('Pyr to BC')
xdummy = [0];
g = plot( currentData(:, 1), currentData(:, 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2);

linn = line ([max_x-45 max_x-15], [min_y+1.5 min_y+1.5], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(max_x-45, max_y-0.4 ,'30ms')

linn = line ([max_x-3 max_x-3], [max_y-0.3 max_y-0.8], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(max_x, max_y - 0.55,'0.5mv')

% set the y-axis back to normal.
set(gca,'ydir','normal');
axis off


%% OLM
subplot(subx,suby,3)
currentData = importdata('OLMf.txt');
min_x = 0;
max_x = 89.7; % calculated duration
min_y = -68.1;
max_y = -63.39; % height is 1.61 mv

bio = imread('OLMfacilitation.png');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;


xdummy = [0];

title('Pyr to OLM')
xdummy = [0];
g = plot( currentData(:, 1), currentData(:, 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2);

linn = line ([max_x-20 max_x-0], [max_y-.4 max_y-.4], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(max_x-18, max_y-0.9 ,'20ms')

linn = line ([max_x-3 max_x-3], [max_y-1.5 max_y-2.5], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(max_x, max_y - 2,'0.5mv')
% set the y-axis back to normal.
set(gca,'ydir','normal');
axis off

%% BC to Pyr
subplot(subx,suby,4)
currentData = importdata('BC2pyr_depression.txt');

min_x = 0;
max_x = 282; % calculated duration
min_y = -0.09743;
max_y = 0.00133; % height is 1.61 mv

bio = imread('BC2PYRDepression.jpg');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;


xdummy = [0];

title('BC to Pyr')

g = plot( currentData(:, 1), -currentData(:, 2), 'r', xdummy, xdummy, 'k', xdummy, xdummy, 'g', 'LineWidth',2);

linn = line ([max_x-120 max_x-160], [max_y-.07 max_y-.07], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(max_x-156.63636, max_y-0.0862 ,'30ms')

linn = line ([max_x-90 max_x-90], [max_y-0.04 max_y-0.09], 'LineWidth', 2);
set(linn, 'Color', [0 0 0])
text(max_x-85, max_y - 0.09,'500pA')


% legend(g, 'Simulation', 'Recordings', 'Average' , 'Location', 'SouthEast')
% legend boxoff

% set the y-axis back to normal.
set(gca,'ydir','normal');
axis off

