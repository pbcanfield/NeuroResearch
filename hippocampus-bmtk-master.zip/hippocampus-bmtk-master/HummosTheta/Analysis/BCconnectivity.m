 close all

%% currentData = importdata('FacilitationMF.dat');
xxx = (19 * 60 + 20)/1000;
min_x = 0;
max_x = xxx; %calculated duration 225 
min_y = -0.15;
max_y = 1.2;
% figure1 = figure('Color',[1 1 1]);
bio = imread('BCconnectivity.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;

dist = 0:0.001:xxx;
c = .2;
prob =	 1 ./(exp( ((abs(dist) -0.6).^2)./ (2 * (c^2))));

plot(dist, prob);
% plot( currentData(cut:size(currentData,1), 1) , currentData(1:sc, 2) )
% g = plot( currentData(:, 1), currentData(:, 2), 'b', xdummy, xdummy, 'k', 'LineWidth',3);
% j = plot(xdummy, xdummy, 'k', 'LineWidth', 3)
% legend(g, 'Simulation', 'Recordings' , 'Location', 'SouthWest')
% legend boxoff

% legend(j, 'recording', 'Location', 'SouthWest')
% set the y-axis back to normal.
set(gca,'ydir','normal');
% axis off