
function plotCon(loc, CurrentPosition)

x = CurrentPosition(1,1);
y = CurrentPosition(1,2);
z = CurrentPosition(1,3);

xm = 100;
ym = 100;
zm = 100;

for m = 1:size(loc,2)
   for n = 1:size(loc{m}, 1)
       if (( abs (loc{m}(n,1) - x ) <= abs(xm - x)) && ( abs (loc{m}(n,2) - y ) <= abs(ym - y)) && ( abs (loc{m}(n,3) - z ) <= abs(zm - z)))
           area = m; id = n;
           xm = loc{m}(n,1);
           ym = loc{m}(n,2);
           zm = loc{m}(n,3);
       end
   end
end

disp(area)
disp(id)

% dest = round(CurrentPosition(1,1));
% src = round(CurrentPosition(1,2));
% disp(CurrentPosition)
% 
% dest = dest;
% 
% if src>0
%     src = src;
% end
% weID = 0;
%   for n = 1:size(con, 1)
%            if ((con(n, 2) == preArea) && (con(n,3) == src-1) && (con(n,4) == postArea) && (con(n,5) == dest-1))
%                weID = con(n,1);
%            end
%   end
% 
%   if (weID > 0)
% col = find(Wts(1,:) == weID);
% figure(3); plot(Wts(2:end,1)/1000, Wts(2:end, col))
%   end