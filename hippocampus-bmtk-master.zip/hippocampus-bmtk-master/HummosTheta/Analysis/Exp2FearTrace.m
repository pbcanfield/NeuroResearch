OutPath = '..\Outputs\';
cellNumbers = [30 63 384 20 20];
areaCode = [0 1 4 7 8];

% FEAR

StimCount = 15;
tstop = 12000;
StimSpace = tstop / StimCount;
reference =5;

i = 4;
SpikeTimes = importdata([OutPath '019SpikeTime' num2str(areaCode(i)) '.txt']);
[TN1, cor1] = ParseTrialsCS(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);

i = 5;
SpikeTimes = importdata([OutPath '019SpikeTime' num2str(areaCode(i)) '.txt']);
[TN2, cor2] = ParseTrialsCS(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);

figure
plot (cor1, 'r'); 
hold on
plot (cor2, 'b')

%% DrawSpikeTimes    
i = 5;
close all;
ST1 = FilterStimSpace(SpikeTimes, StimSpace, 0.156);


%% count fear
OutPath = '..\Outputs\';
cellNumbers = [30 63 384 20 20];
areaCode = [0 1 4 7 8];

% FEAR

StimCount = 17;
tstop = 12000;
StimSpace = tstop / StimCount;
reference =5;

i = 5;
SpikeTimes = importdata([OutPath '0192SpikeTime' num2str(areaCode(i)) '.txt']);
[TN1, cor1] = ParseTrialsCS(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);


SpikeTimes = importdata([OutPath '2192SpikeTime' num2str(areaCode(i)) '.txt']);
[TNACH, corACH] = ParseTrialsCS(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);

fearSumACH = sum(TNACH(:,1:5), 2);
extSumACH = sum(TNACH(:,6:10), 2);


fearSum = sum(TN1(:,1:5), 2);
extSum = sum(TN1(:,6:10), 2);
figure(3);
hold off
plot (fearSum, 'r');
hold on
plot(extSum, 'b');
plot (fearSumACH, 'ro');
plot(extSumACH, 'bo');  
legend('Fear Low ACH', 'Ext low ACH', 'Fear high ACH', 'Ext high ACH')