for sname = fn
    disp(sname{1})
    
end
