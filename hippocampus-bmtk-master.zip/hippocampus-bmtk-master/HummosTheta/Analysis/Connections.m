%% Read data
con = importdata('05Connections.txt'); 
weights = importdata('05Weights.txt');
currents = importdata('05Currents.txt');          
%% Plot all incoming to area
close all;

postArea = 1;

pre = []; 

for n = 1:size(con, 1)
       if (con(n,4) == postArea)
           pre(end+1, :)= con(n,:);
       end
end

uni = unique(pre(:, 2));

for m = 1:size(uni, 1)
    disp(uni(m))
    tvec = weights(2:end, 1);
    figure(m)
    set(gcf,'Position',[36         180*(m-1)        1251         165])
    set(gca,'Position',[ 0.0435    0.1910    0.9365    0.6935])

    xlabel('Time (ms)'); ylabel('weight');
    hold on;
    count = 0;
    for n = 1:size(pre, 1)

       if ( (pre(n,2) == uni(m)) && (count < 200) )
           col = find(weights(1, :) == pre(n,1));
           gain = weights(end, col) - weights(2, col);
            %if (abs(gain) > 0.002)
               plot(tvec, weights(2:end, col))
               %disp(weights(1,col))
               count = count +1;
            %end
       end
    title(['From area ' num2str(uni(m)) ' count: ' num2str(count)])       
    end    
end

%% Plot presynaptic connections of one cell
close all;

target = 110;
postArea = 4;

pre = []; 

for n = 1:size(con, 1)
       if ((con(n,4) == postArea) && (con(n,5) == target))        
           pre(end+1, :)= con(n,:);
       end
end
  
% divide connections by area
% plot weights from each area with area name in label and source neurons
% in legend
%preferably also get neurons v and u

uni = unique(pre(:, 2));


for m = 1:size(uni, 1)
    disp(uni(m))
    tvec = weights(2:end, 1);
    figure(m)
    set(gcf,'Position',[36         200*(m-1)        1251         180])
    set(gca,'Position',[ 0.0435    0.1910    0.9365    0.6935])

    xlabel('Time (ms)'); ylabel('weight');
    hold on;
    count = 0;
    for n = 1:size(pre, 1)
       if (pre(n,2) == uni(m))
           col = find(weights(1, :) == pre(n,1));
           plot(tvec, weights(2:end, col))
           count = count +1;
       end
    title(['From area ' num2str(uni(m)) ' count: ' num2str(count)])       
    end    
end

%% Connection number statisitics
DGindex = find(con(:,4) == 4);
DGcon = con(DGindex,:); %alternatively DGcon = con( con(:,4) == 4, :);
DGcells = unique(DGcon(:,5));

fromOLM = zeros(size(DGcells));
fromBC = zeros(size(DGcells));
fromEC = zeros(size(DGcells));

for d = 1:size(DGcells) 
    Cellcon = DGcon(   find(DGcon(:,5) == d -1),:);
        for h = 1:size(Cellcon, 1)
           if (Cellcon(h, 2) == 0); fromEC(d) = fromEC(d) + 1; end
           if (Cellcon(h, 2) == 5); fromOLM(d) = fromOLM(d)+ 1; end               
           if (Cellcon(h, 2) == 6); fromBC(d)  = fromBC(d)+ 1; end
           
        end
end

subplot(3,1, 1); x = 0:1:15; hist(fromOLM, x); title('From OLM');
subplot(3,1, 2); x = 0:1:10; hist(fromBC, x); title('From BC');
subplot(3,1, 3); x = 0:1:15; hist(fromEC, x); title('From EC');

%% Connection number statisitics CA3
DGindex = find(con(:,4) == 1);
DGcon = con(DGindex,:); %alternatively DGcon = con( con(:,4) == 4, :);
DGcells = unique(DGcon(:,5));

fromOLM = zeros(size(DGcells));
fromBC = zeros(size(DGcells));
fromEC = zeros(size(DGcells));

for d = 1:size(DGcells) 
    Cellcon = DGcon(   find(DGcon(:,5) == d -1),:);
        for h = 1:size(Cellcon, 1)
           if (Cellcon(h, 2) == 0); fromEC(d) = fromEC(d) + 1; end
           if (Cellcon(h, 2) == 2); fromOLM(d) = fromOLM(d)+ 1; end               
           if (Cellcon(h, 2) == 3); fromBC(d)  = fromBC(d)+ 1; end
           
        end
end

subplot(3,1, 1); x = 0:1:15; hist(fromOLM, x); title('From OLM');
subplot(3,1, 2); x = 0:1:10; hist(fromBC, x); title('From BC');
subplot(3,1, 3); x = 0:1:15; hist(fromEC, x); title('From EC');

%% connection average numbers
from = unique(con(:,2));
to = unique(con(:,4));

for s = 1:size(from)
%     stat(1,s+1) = s; 
    for t = 1:size(to)
%         stat(t+1, 1) = t;
        tot = [];
        for n = 1:size(con, 1)
       if ((con(n,2) == from(s)) && (con(n,4) == to(t)))        
           tot(end+1, :)= con(n,:);
       end
        end
        
        if (size(tot,1) > 0)
        su = size(tot, 1);
        
        no = size(unique(tot(:,3)), 1);
        
        average = su/no;
        else
            average = 0;
        end
        stat(t, s) = average;
            if (average > 0)
                disp(['from: ' num2str(s-1) ' to: ' num2str(t-1) ' --> ' num2str(average)])
            end
    end
    
end
figure
surf(from, to, stat)


%% stats

pres = unique (con(:, 2));
posts = unique (con(:, 4));
results = {};
for pr = 0:size(pres)-1
   for po = 0:size(posts)-1
      specificPre = con(con(:,2) == pr & con(:,4) == po, :);
      if (size(specificPre, 1) > 0)
        preNeuronNum = size( unique(specificPre(:, 3)), 1);
        postNeuronNum = size( unique(specificPre(:, 5)), 1);
      
      
      results{end+1} =(['on average each neuron in area ' num2str(po) ' recieves ' num2str(size(specificPre,1)/postNeuronNum) ' from ' num2str(pr)]);
       end
    end
end