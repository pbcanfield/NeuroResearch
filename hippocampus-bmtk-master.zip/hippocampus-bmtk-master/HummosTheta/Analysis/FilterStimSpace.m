function [ FilteredST] = FilterStimSpace(SpikeTimes, StimSpace, Frac )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

ST1 = [0, 0];
% ST2 = [0, 0];

    for y = 1:size(SpikeTimes, 1)
        kosor = rem(SpikeTimes(y, 2),StimSpace)     /   StimSpace;
        if (kosor < Frac)
%             SpikeTimes(i, :) = [];
            ST1 = [ST1; SpikeTimes(y, :)];
        end
    end
   FilteredST = ST1;
   
end

