
function plotwt(Wts,con,preArea, postArea,CurrentPosition)

dest = round(CurrentPosition(1,1));
src = round(CurrentPosition(1,2));


if src>0
    src = src;
end
weID = 0;
  for n = 1:size(con, 1)
           if ((con(n, 2) == preArea) && (con(n,3) == src-1) && (con(n,4) == postArea) && (con(n,5) == dest-1))
               weID = con(n,1);
           end
  end
  
disp(weID);

  if (weID > 0)
col = find(Wts(1,:) == weID);
figure(3);
set(gcf, 'Color', [1 1 1]); set(gcf,'Position',[10   300   500   300]);

plot(Wts(2:end,1)/1000, Wts(2:end, col))
  else
      delete(figure(3));
  end
  
% disp([src dest])

% if src>=0
% col = intersect(find(Wts(1,:)==src-1),find(Wts(2,:)==dest-1));
% else
% col = intersect(find(Wts(1,:)==src),find(Wts(2,:)==dest-1));
% end
% 
% if ~isempty(col)
% figure(3);plot(Wts(2:end,1)/1000,Wts(2:end,col))
% set(gcf,'Position',[36         371        1751         199])
% set(gca,'Position',[ 0.0435    0.1910    0.9365    0.6935])
% 
% 
% if src>=0
% title([num2str(src) ' \rightarrow ' num2str(dest)])
% elseif src~=-6    
% title(['CS' num2str(-src) ' \rightarrow ' num2str(dest)])
% else
% title(['US' ' \rightarrow ' num2str(dest)]) 
% end
% 
% xlabel('Time (sec)')
% ylabel('Weight')
end
