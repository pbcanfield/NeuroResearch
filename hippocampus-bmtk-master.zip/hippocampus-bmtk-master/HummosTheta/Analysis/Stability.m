outPath = '..\Outputs\';
stabFiles = dir ([outPath 'sumsActive*.txt']);
stabf = [{stabFiles.name}];

stabs = [];
for filename = stabf
   stab = importdata( [outPath filename{1}] ); 
   stabs  = [stabs stab];
   
end

%% somethig else
% stabs = importdata('stabsWithFaci.txt');
figure()
av = mean(stabs, 2);
plot(av);
figure()
plot(stabs)
