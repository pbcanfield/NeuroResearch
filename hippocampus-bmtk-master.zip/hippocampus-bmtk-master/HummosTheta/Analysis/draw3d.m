function draw3d (preArea, preID, postArea, postID, which, con)
OutPath = '..\Outputs\';
locFiles = dir([OutPath 'Loc*.txt']);
% col = ['mp'; 'mp'; 'r>'; 'go'; 'mp'; 'k>'; 'go' ];
col2 = {'mp'; 'kp'; 'r>'; 'go'; 'bp'; 'k>'; 'go' ;  'kp'; 'kp'; 'r>'; 'r>'}; %using CELL ARRAYS as indicated by the curly braces!

for i = 1:size(locFiles)
       stg = [OutPath locFiles(i).name];
       loc = importdata(stg);
        y{i} = loc ;     
% plot3(loc(:,1), loc(:,2), loc(:,3),  col(i, :), 'MarkerFaceColor', [0 1 0] )
H = plot3(loc(:,1), loc(:,2), loc(:,3),  col2{i});  %, 'MarkerFaceColor', [0 1 0] )
set(H,'ButtonDownFcn','disp(get(gca,''CurrentPoint'')); plotCon(y, get(gca, ''CurrentPoint''))');
hold on;
       
end

legend('EC', 'CA3 pyramidal', 'CA3 OLM', 'CA3 BC', 'DG granule', 'DG HIPP', 'DG BC', 'Emo1E', 'Emo2E', 'Emo1i', 'Emo2i');

y{1}(1,:)


for n = 1:size(con, 1)
   qpreArea = con(n,2);
   qpreID = con(n,3);
   qpostArea= con(n,4);
   qpostID = con(n,5);
   
   if (strcmp (which,'pre'))
       if (qpreID == preID && qpreArea == preArea)
        preLoc = y{qpreArea +1}(qpreID+1,:);
        postLoc = y{qpostArea +1}(qpostID+1,:);
        lineLoc = [preLoc; postLoc];
       	line(lineLoc(:,1), lineLoc(:,2), lineLoc(:,3), 'LineWidth', 1)
       end
   else
       if (qpostID == postID && qpostArea == postArea)
           preLoc = y{qpreArea +1}(qpreID+1,:);
        postLoc = y{qpostArea +1}(qpostID+1,:);
        lineLoc = [preLoc; postLoc];
       	line(lineLoc(:,1), lineLoc(:,2), lineLoc(:,3), 'LineWidth', 1)
       end
   end
end