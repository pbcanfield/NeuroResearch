function varargout = ViewMain(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ViewMain_OpeningFcn, ...
                   'gui_OutputFcn',  @ViewMain_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ViewMain is made visible.
function ViewMain_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure

% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ViewMain (see VARARGIN)

% Choose default command line output for ViewMain
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ViewMain wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% OutPath = getappdata(0, 'OutPath');
% loc_con =       importdata([OutPath 'Connections.txt']); 
% loc_weights =   importdata([OutPath 'Weights.txt']);
% loc_currents =  importdata([OutPath 'Currents.txt']);
loc_con = 0; loc_weights = 0; loc_currents = 0;
loc_areas = {'EC'; 'CA3e'; 'CA3o'; 'CA3b'; 'DGg'; 'DGh'; 'DGb'};

setappdata(0, 'con'     , loc_con)
setappdata(0, 'weights' , loc_weights)
setappdata(0, 'currents', loc_currents)
setappdata(0, 'areas'   , loc_areas)
setappdata(0, 'digits'  , '05')
figs = [];
setappdata(0, 'figs'    , figs)
setappdata(0, 'OutPath', '..\Outputs\')

% --- Outputs from this function are returned to the command line.
function varargout = ViewMain_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure

% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in lbFrom.
function lbFrom_Callback(hObject, eventdata, handles)
% hObject    handle to lbFrom (see GCBO)

% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbFrom contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbFrom


% --- Executes during object creation, after setting all properties.
function lbFrom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbFrom (see GCBO)

% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in lbTo.
function lbTo_Callback(hObject, eventdata, handles)
% hObject    handle to lbTo (see GCBO)

% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbTo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbTo


% --- Executes during object creation, after setting all properties.
function lbTo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbTo (see GCBO)

% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pmFrom.
function pmFrom_Callback(hObject, eventdata, handles)
% hObject    handle to pmFrom (see GCBO)

% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmFrom contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmFrom


% --- Executes during object creation, after setting all properties.
function pmFrom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmFrom (see GCBO)

% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pmTo.
function pmTo_Callback(hObject, eventdata, handles)
% hObject    handle to pmTo (see GCBO)

% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmTo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmTo


% --- Executes during object creation, after setting all properties.
function pmTo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmTo (see GCBO)

% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function eFrom_Callback(hObject, eventdata, handles)
% hObject    handle to eFrom (see GCBO)

% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eFrom as text
%        str2double(get(hObject,'String')) returns contents of eFrom as a double


% --- Executes during object creation, after setting all properties.
function eFrom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eFrom (see GCBO)

% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function eTo_Callback(hObject, eventdata, handles)
% hObject    handle to eTo (see GCBO)

% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTo as text
%        str2double(get(hObject,'String')) returns contents of eTo as a double


% --- Executes during object creation, after setting all properties.
function eTo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTo (see GCBO)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pbTester.
function pbTester_Callback(hObject, eventdata, handles)
% hObject    handle to pbTester (see GCBO)

% handles    structure with handles and user data (see GUIDATA)
gd = gatherData(handles);
con = getappdata(0, 'con');
weights = getappdata(0, 'weights');
currents = 1;
GodPlot(gd, con, weights, currents);

function AllForOne(postArea, postID)
con = getappdata(0, 'con');
weights = getappdata(0, 'weights');

% con = con(find(con(:, 4) == postArea && con(:,5) == postID))

target = postID;

pre = []; 

for n = 1:size(con, 1)
       if ((con(n,4) == postArea) && (con(n,5) == target))        
           pre(end+1, :)= con(n,:);
       end
end
uni = unique(pre(:, 2));

figs = getappdata(0, 'figs');
for f = 1:size(figs)
    try
        close(figs)
    end
end
figs = [];
setappdata(0, 'figs', figs)

for m = 1:size(uni, 1)
    disp(uni(m))
    tvec = weights(2:end, 1);
    figs(end+1) = figure(m);
    set(gcf,'Position',[136         180*(m-1)        800         160])
    set(gca,'Position',[ 0.0735    0.1910    0.9365    0.6935])

   % xlabel('Time (ms)'); ylabel('weight');
    hold on;
    count = 0;
    for n = 1:size(pre, 1)
       if (pre(n,2) == uni(m))
           col = find(weights(1, :) == pre(n,1));
           plot(tvec, weights(2:end, col))
           count = count +1;
       end
    title(['From area ' num2str(uni(m)) ' count: ' num2str(count)])       
    end    
end
setappdata(0, 'figs', figs)

function AllToArea(postArea, postID)
con = getappdata(0, 'con');
weights = getappdata(0, 'weights');
currents = getappdata(0, 'currents');
DataToDraw = weights;

pre = []; 
if (postArea == 8)
    if (sum(postID == [0, 1, 2, 3, 4]))
        for n = 1:size(con, 1)
               if (con(n,4) == postArea && sum(con(n,5) == [0, 1, 2, 3, 4]))
                   pre(end+1, :)= con(n,:);
               end
        end 
    else
          for n = 1:size(con, 1)
                if (con(n,4) == postArea && sum(con(n,5) == [5, 6, 7, 8, 9]))
                    pre(end+1, :)= con(n,:);
                end
          end 
    
    end
else
    for n = 1:size(con, 1)
           if (con(n,4) == postArea)
               pre(end+1, :)= con(n,:);
           end
    end
end
uni = unique(pre(:, 2));

for m = 1:size(uni, 1)
    disp(uni(m))
    tvec = DataToDraw(2:end, 1);
        try
            close(figure(m))
        end
    figure(m)
    set(gcf,'Position',[36         180*(m-1)        1251         165])
    set(gca,'Position',[ 0.0435    0.1910    0.9365    0.6635])

    xlabel('Time (ms)'); ylabel('weight');
    hold on;
    count = 0;
    OutOf = 0;
    for n = 1:size(pre, 1)

       if ( (pre(n,2) == uni(m)) && (count < 200) )
           col = find(DataToDraw(1, :) == pre(n,1));
           gain = DataToDraw(end, col) - DataToDraw(2, col);
%             if (abs(gain) > 0.02)
               plot(tvec, DataToDraw(2:end, col))
               count = count +1;
%             end
            OutOf = OutOf +1;
       end
    title(['From area ' num2str(uni(m)) ' count: ' num2str(count) 'Out of' num2str(OutOf) ])       
    end    
end


% --- Executes on button press in pbAllForOne.
function pbAllForOne_Callback(hObject, eventdata, handles)
% hObject    handle to pbAllForOne (see GCBO)

% handles    structure with handles and user data (see GUIDATA)
con = getappdata(0, 'con');
siz = size(con,1);
set(handles.text1, 'String', num2str(siz))

gathered = gatherData(handles);
disp(['postID is : ' num2str(gathered.postID)]);
disp(['postArea is : ' num2str(gathered.postArea)]);
AllForOne(gathered.postArea, gathered.postID);

% --- Executes on button press in pbAllToArea.
function pbAllToArea_Callback(hObject, eventdata, handles)
gathered = gatherData(handles);
AllToArea(gathered.postArea, gathered.postID);

% --- Executes on button press in pbOneToOne.
function pbOneToOne_Callback(hObject, eventdata, handles)
% hObject    handle to pbOneToOne (see GCBO)

function gathered = gatherData(handles)
gathered.FromTime   = str2num(get(handles.eFrom, 'String'));
gathered.ToTime     = str2num(get(handles.eTo, 'String'));
% gathered.preID      = (get(handles.pmFrom, 'Value'));
% gathered.postID     = (get(handles.pmTo, 'Value'));

% Hints: contents = cellstr(get(hObject,'String')) returns pmTo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmTo

strs = cellstr(get(handles.pmTo, 'String'));
ind = (get(handles.pmTo, 'Value'));
selectedSTR = strs{ind};
gathered.postID = str2num (selectedSTR);

strs = cellstr(get(handles.pmFrom, 'String'));
ind = (get(handles.pmFrom, 'Value'));
selectedSTR = strs{ind};
gathered.preID = str2num (selectedSTR);

areas = getappdata(0, 'areas');

gathered.postArea = get(handles.lbTo, 'Value');

gathered.preArea = get(handles.lbFrom, 'Value') -1;


% --- Executes on button press in pbDraw3dpost.
function pbDraw3dpost_Callback(hObject, eventdata, handles)
gatheredData = gatherData(handles);
con = getappdata(0, 'con');
figure(10);
draw3d(gatheredData.preArea, gatheredData.preID, gatheredData.postArea, gatheredData.postID, 'post', con)

% --- Executes on button press in pbDraw3dPre.
function pbDraw3dPre_Callback(hObject, eventdata, handles)
gatheredData = gatherData(handles);
con = getappdata(0, 'con');
figure(10);
draw3d(gatheredData.preArea, gatheredData.preID, gatheredData.postArea, gatheredData.postID, 'pre', con)


% --- Executes on button press in pbStats.
function pbStats_Callback(hObject, eventdata, handles)
% hObject    handle to pbStats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
con = getappdata(0, 'con');
pres = unique (con(:, 2));
posts = unique (con(:, 4));
results = {};
for pr = 0:size(pres)-1
   for po = 0:size(posts)-1
      specificPre = con(con(:,2) == pr & con(:,4) == po, :);
      if (size(specificPre, 1) > 0)
        preNeuronNum = size( unique(specificPre(:, 3)), 1);
        postNeuronNum = size( unique(specificPre(:, 5)), 1);
      
      
      results{end+1} =(['on average each neuron in area ' num2str(po) ' recieves ' num2str(size(specificPre,1)/postNeuronNum) ' from ' num2str(pr)]);
       end
    end
end
yyy = ylim;

ymax = yyy(2);
yinc = (yyy(2)-yyy(1))/25;

for i = 1:size(results, 2)
    text(0.05, ymax - yinc * i, results{i});
    disp(results{i})
end


% --- Executes on button press in pbSpikes.
function pbSpikes_Callback(hObject, eventdata, handles)
  gd = gatherData(handles);
  digits = getappdata(0, 'digits');
  OutPath = getappdata(0, 'OutPath');
    SpikeTimes = importdata([OutPath digits 'SpikeTime' num2str(gd.preArea) '.txt']);
%    H = figure();
    plot(SpikeTimes(:,2), SpikeTimes(:,1), 'rx', 'MarkerSize', 3);
    
% set(H, 'ButtonDownFcn', 'disp(get(gcf,''CurrentPoint''));');
%[x1, y1] = ginput(1)

% --- Executes on button press in pbClear.
function pbClear_Callback(hObject, eventdata, handles)
cla(handles.aMain);

function GodPlot(gd, con, weights, currents)

from = 0; to = 500;
gd.postArea = 3;
gd.postID = 4;
% con weights currents 

incoming = con (con(:,4) == gd.postArea & con(:,5) == gd.postID , :);

uniAreas = unique(incoming(:, 2));

for p = 1:size(uniAreas)
   areaSpecific = incoming(incoming(:,2) == uniAreas(p), :); 
   syn = struct();
   for i = 1:size(areaSpecific, 1)
    synSize = size(syn ,2);
    syn(synSize).ID =         areaSpecific(i, 1);
    syn(synSize).preArea =    areaSpecific(i, 2);
    syn(synSize).preID =      areaSpecific(i, 3);
    syn(synSize).postArea =   areaSpecific(i, 4);
    syn(synSize).postID =     areaSpecific(i, 5);
    syn(synSize).type =       areaSpecific(i, 6);
    syn(synSize).weight =     weights(2:end, (weights(1,:) == areaSpecific(i, 1)));
    syn(synSize).current =    currents(2:end, (currents(1,:) == areaSpecific(i, 1)));
       syn(synSize + 1).ID = 0;
   end
   
%    choosen = [];
%    for s = 1:size(syn, 2)
%       pp = (abs(syn(s).current) > 0.01);
%       
%       gain = syn(s).weight(end) - syn(s).weight(1);
%       if (sum(pp) || (gain > 0.01))
%          choosen (end+1) = syn(s).ID; 
%       end
%    end
   
   %selected = syn( syn.current > 0.01
   
   figure('Position', [0 200 * (p-1) 600 200]);

    plots = size(areaSpecific, 1);
   % check if significant weight or current changes
   % plot specific times;
 
%    twvec2 = weights(2:end, 1);
%    twvec = twvec2(twvec2 >= from & twvec2 <= to);
   twvec = weights(2:end, 1);
   for j = 1:size(areaSpecific)
       subplot(1, plots, j);
       subplot('Position',[ 1/plots*(j-1)    0.0910    .8/plots    0.8])
       
       plot(twvec, syn(j).weight); 
          title(num2str(syn(j).ID));
         xlim([from to]); ylim([0 4]);
   end
   figure('Position', [700 200*(p-1) 600 200]);
   tcvec = currents(2:end,1);

   plot(tcvec, [syn.current] ); % this access ALL current fields and puts them into an array!!
    xlim([from to]);
    set(gca,'Position',[ 0.0435    0.0910    0.9965    0.9935])
 end


% --- Executes on selection change in pmFileNames.
function pmFileNames_Callback(hObject, eventdata, handles)
% loc_weights= importdata(hObject.Value
strs = (get(hObject, 'String'));
ind = (get(hObject, 'Value'));
selectedSTR = strs{ind};

digitsNo = sum(isstrprop(selectedSTR, 'digit'));

setappdata(0, 'digits', selectedSTR(1:digitsNo));
RefreshFiles()
weights = getappdata(0, 'weights');
set(handles.eTo, 'String', num2str(weights(end, 1) ))

function RefreshFiles()
OutPath = getappdata(0, 'OutPath');
dig = getappdata(0, 'digits');
loc_con = importdata([OutPath dig 'Connections.txt']);
loc_weights = importdata([OutPath dig 'Weights.txt']);
loc_currents = importdata([OutPath dig 'Currents.txt']);

setappdata(0, 'con', loc_con)
setappdata(0, 'weights', loc_weights)
setappdata(0, 'currents', loc_currents)




% --- Executes during object creation, after setting all properties.
function pmFileNames_CreateFcn(hObject, eventdata, handles)
OutPath = getappdata(0, 'OutPath');
weightsFiles = dir ([OutPath '*Weights*.txt']);
names = {weightsFiles.name};
set(hObject, 'String', names);

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
