%% Data
con = importdata('Connections.txt');
weights = importdata('Weights.txt');

%% Surf
close all

preArea = 0;
postArea = 4;
preNum = 30;
postNum = 100;


% 
% wid = con(10,1);
% 
% index = find(weights(1,:) == wid);
% si = size(weights(2:size(weights,1)), 2);
% time = .1:0.1:si*.1;
% plot(time, weights(2:size(weights, 1), index))

zer = zeros(preNum, postNum);
col = zeros(preNum, postNum);
ids = zeros(preNum, postNum);
% col = zeros(postNum, preNum);
% ids = zeros(postNum, preNum);

for i = 1:preNum 
   for j = 1:postNum
%        ind = find(con, [preArea i postArea j]);
        for n = 1:size(con, 1)
           if ((con(n, 2) == preArea) && (con(n,3) == i-1) && (con(n,4) == postArea) && (con(n,5) == j-1))
               ids(i,j) = con(n,1);
               col(i,j) = 1;
           end
        end
   
   end
end

F=figure(2);
H = surf([.5:postNum-.5] , [0.5:preNum-.5], zeros(preNum,postNum), col); %, 'EdgeColor',[0.5 0.5 0.5]);
view(0,90)
colormap(flipud(hot))
xlim([0.5 postNum-.5])
ylim([0.5 preNum-.5])
box off
set(gcf,'Position',[573   40   700   650])
set(gca,'XTick',[1:round(postNum/25):postNum],'YTick',[1:round(preNum/25):preNum],'ZTick',[],'Position',[0.0725    0.0570    0.9089    0.9179])
set(gca,'TickDir','out','TickLength',[0.004 0],'XMinorGrid','on')
set(gca,'GridLineStyle','none','MinorGridLineStyle','none')
xlabel('Target');ylabel('Source')

T=[];R1=[];R2=[];
set(F,'WindowButtonMotionFcn','[R1,R2,T]=highlightconn(R1,R2,T,get(gca,''CurrentPoint''),preNum, postNum);')

set(H,'ButtonDownFcn','plotwt(weights,con, preArea, postArea, get(gca,''CurrentPoint''));figure(2)');



% H = surf(0:preNum-1, 0:postNum-1 , zeros(preNum,postNum), col); %, 'EdgeColor',[0.5 0.5 0.5]);
% view(0,90)
% colormap(flipud(hot))
% xlim([0 (preNum-1)])
% ylim([0 (postNum-1)])
% % box off
%  set(gcf,'Position',[ 75         0        1000         900])
% %  set(gca,'XTick',[0:round(preNum/25):preNum],'YTick',[0:round(postNum/25):postNum],'ZTick',[],'Position',[0.0410 0.1921 0.9404 0.7329])
%  set(gca,'TickDir','out','TickLength',[0.002 0],'XMinorGrid','on')
%  set(gca,'GridLineStyle','none','MinorGridLineStyle','none')
 
% set(H,'ButtonDownFcn','val = get(gca,''CurrentPoint''); val(1,2)=-val(1,2); plotwt(X,val);figure(1);');
% set(gcf,'CloseRequestFcn','delete(figure(1));delete(figure(2));delete(figure(3));');



