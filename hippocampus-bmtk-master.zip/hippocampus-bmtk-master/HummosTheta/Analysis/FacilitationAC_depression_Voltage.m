% close all
close all
figure('Position', [100, 100, 800, 200])
%%
currentData = importdata('CA3AC.txt');
% 
min_x = 1;
max_x = 209;
min_y = 73.7;
max_y = 75.4;

bio = imread('AC50Hz2.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;

cut = 001;

sc = size(currentData,1) - cut +1;

xdummy = [0];
 
tindex = find(currentData(:,1) < 200);
tvec= (currentData(tindex,1));
vvec = (currentData(tindex,2));
% plot( currentData(cut:size(currentData,1), 1) , currentData(1:sc, 2) )
g = plot( currentData(1:sc, 1), -currentData(cut:size(currentData,1), 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2);
% j = plot(xdummy, xdummy, 'k', 'LineWidth', 3)
legend(g, 'Simulation', 'Recordings' , 'Location', 'SouthEast')
% legend boxoff

% legend(j, 'recording', 'Location', 'SouthWest')
% set the y-axis back to normal.
set(gca,'ydir','normal');
% axis off

%% prepare
figure('Position', [100, 300, 800, 200])
%% Facilitation 20Hz
currentData = importdata('CA3ACVoltage20Hz.txt');

min_x = 0;
max_x = 500;
min_y = 73.9;
max_y = 75.25;

bio = imread('AC20Hz2.JPG');
imagesc([min_x max_x], [min_y max_y], flipdim(bio, 1));
hold on;

cut = 001;

sc = size(currentData,1) - cut +1;

xdummy = [0];
 
tindex = find(currentData(:,1) < 500);
tvec= (currentData(tindex,1));
vvec = (currentData(tindex,2));
% plot( currentData(cut:size(currentData,1), 1) , currentData(1:sc, 2) )
g = plot( currentData(1:sc, 1), -currentData(cut:size(currentData,1), 2), 'r', xdummy, xdummy, 'k', 'LineWidth',2)
% g= plot (tvec, vvec, 'r', 'LineWidth', 2);
% legend(j, 'recording', 'Location', 'SouthWest')
% set the y-axis back to normal.
set(gca,'ydir','normal');