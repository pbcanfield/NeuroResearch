
OutPath = '..\Outputs\';
cellNumbers = [30 63 384 20 20];
areaCode = [0 1 4 7 8];

StimCount = 16;
StimSpace = 625 ;% tstop / StimCount;
tstop = 10000;
reference =6;

% FEAR

StimCount = 15;
tstop = 12000;
StimSpace = tstop / StimCount;
reference =5;

ST1 = [0, 0];
ST2 = [0, 0];
ST3 = [0, 0];

sig = 0.7;
i = 2;
SpikeTimes = importdata([OutPath '2196SpikeTime' num2str(areaCode(i)) '.txt']);

[hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);

cocode = zeros(size(hell,2), 1);
  for n = 1:size(hell,2)
      Slearn = sum(hell(1:reference, n)) ;
      Sretrieve = sum(hell(reference+1:end-1, n));
      
      if ((Slearn > sig) && (Sretrieve > sig))  % Active in all patterns
          cocode(n)  = 1;
          ST1 = [ST1; SpikeTimes(SpikeTimes(:,1) == n-1, :)];
          
      else if (Slearn > sig && Sretrieve < sig ) % shuts down
              cocode(n) = 2;
          ST2 = [ST2; SpikeTimes(SpikeTimes(:,1) == n-1, :)];
          end
          if (Slearn < sig && Sretrieve > sig ) % becomes active
              cocode(n) = 3;
              ST3 = [ST3; SpikeTimes(SpikeTimes(:,1) == n-1, :)];
          end
      end
  end
  
figure('Position', [100 100 600 400]);
plot(ST1(:,2), ST1(:,1), 'rx', 'MarkerSize', 3);
hold on;
plot(ST2(:,2), ST2(:,1), 'bx', 'MarkerSize', 3);
plot(ST3(:,2), ST3(:,1), 'kx', 'MarkerSize', 3);


% figure(2);
% plot(SpikeTimes(:,2), SpikeTimes(:,1), 'rx', 'MarkerSize', 3);

% To produce color coded plots I need to separate the data and then plot with one color for each
% color = {'r', 'b', 'g'};
% hold on;
% for i = 1: 3
%     SpikeTimes = importdata([OutPath '29SpikeTime' num2str(areaCode(i)) '.txt']);
%     figure;
%     plot(SpikeTimes(:,2), SpikeTimes(:,1), 'rx', 'MarkerSize', 3);
%     figure(1);
%     hold on
%     [hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);
%     plot(cor, color{i});
% end
% 
