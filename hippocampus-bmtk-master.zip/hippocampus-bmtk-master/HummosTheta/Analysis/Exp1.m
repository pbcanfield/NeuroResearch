OutPath = '..\Outputs\';
exper = 1;

expSig = '00*1';

cellNumbers = [30 63 384 20 20];
areaCode = [0 1 4 7 8];

StimCount = 16;
StimSpace = 625 ;% tstop / StimCount;
tstop = 10000;
reference =6;
corrEC = [];
corrCA3 = [];
corrDG = [];

%% EC
i = 1;
fileNames = dir([OutPath expSig '*SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);
    [hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);
    corrEC = [corrEC; cor];
end

%% CA3
i = 2;
fileNames = dir([OutPath expSig '*SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);
    [hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);
    corrCA3 = [corrCA3; cor];
end


i = 3;
fileNames = dir([OutPath expSig '*SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);
    [hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);
    corrDG = [corrDG; cor];
end

%% exp 2
if (exper == 2)
   expSig = '20';
   corrEC2 = [];
   corrCA32 = [];
   corrDG2 = [];
   
   % CA3
    i = 2;
    fileNames = dir([OutPath expSig '*SpikeTime' num2str(areaCode(i)) '.txt']);
    fn = {fileNames.name};
    for sname = fn
        SpikeTimes = importdata([OutPath sname{1}]);
        [hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);
        corrCA32 = [corrCA32; cor];
    end

    i = 3;
    fileNames = dir([OutPath expSig '*SpikeTime' num2str(areaCode(i)) '.txt']);
    fn = {fileNames.name};
    for sname = fn
        SpikeTimes = importdata([OutPath sname{1}]);
        [hell, cor] = ParseTrials(StimCount, cellNumbers(i), tstop, SpikeTimes, reference);
        corrDG2 = [corrDG2; cor];
    end 
    
    mcorrCA32 = mean (corrCA32, 1);
    mcorrDG2 = mean (corrDG2, 1);
end

%% plot
mcorrEC = mean (corrEC, 1);
mcorrCA3 = mean (corrCA3, 1);
mcorrDG = mean (corrDG, 1);

figure('Color',[1 1 1], 'ToolBar', 'none')
hold off;
ECfit  = plot (mcorrEC(6:end), 'r', 'LineWidth', 2);
hold on;
CA3fit = plot(mcorrCA3(6:end), 'b', 'LineWidth', 2);
if (exper == 1)
    DGfit  = plot(mcorrDG(6:end), 'g', 'LineWidth', 2);
else
    CA32fit  = plot(mcorrCA32(6:end), 'g', 'LineWidth', 2);
    DGfit  = plot(mcorrDG(6:end)); %, 'LineWidth', 3, 'LineStyle', '-.', 'Color', [0 0.5 0], 'Marker', '.');
    DG2fit  = plot(mcorrDG2(6:end)); %, 'g', 'LineWidth', 2);
end

ylim([0 1]);
xlim([0 12]);

set(ECfit                         , ...
  'Color'           , [0 0 .5]    , ...
  'LineWidth'       , 2           );
set(CA3fit                            , ...
  'Color'           , [0.9 .2 .2]  , ...
  'LineWidth'       , 2           , ...
  'Marker'          , 'o'         , ...
  'MarkerSize'      , 6           , ...
  'MarkerEdgeColor' , [.5 .2 .2]  , ...
  'MarkerFaceColor' , [.9 .7 .7]  );


if (exper == 1)
   set(DGfit                         , ...
  'LineStyle'       , '-.'      , ...
    'LineWidth'       , 3       , ...
      'Color'           , [0 .5 0]  , ...
  'Marker'          , '.'         );
else
   set(CA32fit                         , ...
  'Color'           , [0.2 .9 .2]  , ...
  'LineWidth'       , 2           , ...
  'Marker'          , 's'         , ...
  'MarkerSize'      , 6           , ...
  'MarkerEdgeColor' , [.2 .5 .2]  , ...
  'MarkerFaceColor' , [.7 .9 .7]  );
 set([DGfit, DG2fit]                  , ...
  'LineStyle'       , '--'      , ...
    'LineWidth'       , 2.5       , ...
      'Color'           , [0 0 .5]   );
  
set (DG2fit, ...
      'LineStyle'       , '-.'      , ...
      'Marker'          , '.'        , ...
    'Color'         , [0 0.5 0]);
end


hTitle  = title     (''  );
hXLabel = xlabel    ('Patterns pairwise comparison'     );
hYLabel = ylabel    ('Correlation compared to pattern 1');

if (exper == 1)
    hLegend = legend('EC', 'CA3', 'DG', 'Location', 'NorthEast');
else
    hLegend = legend('EC', 'CA3 low ACH', 'CA3 high ACH', 'DG low ACH', 'DG high ACH', 'Location', 'NorthEast');
end
    
legend boxoff


set( gca                       , ...
    'FontName'   , 'Helvetica' );
set([hTitle, hXLabel, hYLabel], ...
    'FontName'   , 'Helvetica');
set([hLegend, gca]             , ...
    'FontSize'   , 8           );
set([hXLabel, hYLabel]  , ...
    'FontSize'   , 10          );
set( hTitle                    , ...
    'FontSize'   , 12          , ...
    'FontWeight' , 'bold'      );

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'YTick'       , 0:.2:1    , ...
  'XTick'       , 1:1:11    , ...
  'LineWidth'   , 1         );


set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 finalPlot2.eps
% print -depsc2 finalPlot1.eps
% close;
