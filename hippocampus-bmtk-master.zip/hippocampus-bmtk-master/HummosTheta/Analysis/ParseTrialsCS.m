function [TrialNeurons, cor] = ParseTrialsCS (StimCount, neurons, tstop, SpikeTimes, compareTo)
StimSpace = tstop/ StimCount;

    TrialNeurons= zeros(StimCount, neurons);
    for i = 1:size(SpikeTimes, 1)
        trialNo = ceil(SpikeTimes(i, 2) / StimSpace);
        kosor = (SpikeTimes(i, 2) / StimSpace) - (trialNo -1);
        if (kosor < 0.5)
            neuronNo = SpikeTimes(i, 1);
            TrialNeurons(trialNo, neuronNo+1) =         TrialNeurons(trialNo, neuronNo+1) + 1;
    
        end
        
    end

    for n = 1:size(TrialNeurons, 1)

        TrialNeurons(n, :) =     TrialNeurons(n, :)./ norm(    TrialNeurons(n, :));
    end

    cor = [];

    for t = 1:size(TrialNeurons, 1)
        cor(end+1) = dot(TrialNeurons(compareTo, :), TrialNeurons(t, :) );
    end

end