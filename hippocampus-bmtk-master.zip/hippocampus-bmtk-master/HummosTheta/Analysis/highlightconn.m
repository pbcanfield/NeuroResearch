function [R1, R2, T]=highlightconn(R1, R2, T,CurrentPoint,preNum, postNum)

if ~isempty(T)
    delete(T)
    delete(R1)
    delete(R2)
end

X = round(CurrentPoint(1,1));
Y = round(CurrentPoint(1,2));

if X>0 && X<=postNum && Y>0 && Y<=preNum
R1 = rectangle('Position',[X-0.5 0.5 1 preNum+0.5],'EdgeColor',[1 0 0],'LineWidth',1.5);
R2 = rectangle('Position',[0.5 Y-0.5 postNum+0.5 1],'EdgeColor',[1 0 0],'LineWidth',1.5);
T = text(X-8,Y+3,1.5,['  ' num2str(Y) ' \rightarrow ' num2str(X) '  '],'BackgroundColor',[0.8 0.9 0.8],'EdgeColor',[0 0 0],'FontWeight','bold','LineWidth',2,'FontSize',15);
else
    T=[];
end
end

