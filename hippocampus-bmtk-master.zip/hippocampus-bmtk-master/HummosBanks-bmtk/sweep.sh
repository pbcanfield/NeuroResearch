python seed_sweep.py 100 0 simulation_config.json &
python seed_sweep.py 200 0 simulation_config.json &
python seed_sweep.py 300 0 simulation_config.json &
python seed_sweep.py 400 0 simulation_config.json &
python seed_sweep.py 500 0 simulation_config.json &

