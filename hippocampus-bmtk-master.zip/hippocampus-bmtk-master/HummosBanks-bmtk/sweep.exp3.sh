python seed_sweep.py 3100 3 simulation_config.exp3.json &
python seed_sweep.py 3200 3 simulation_config.exp3.json &
python seed_sweep.py 3300 3 simulation_config.exp3.json &
python seed_sweep.py 3400 3 simulation_config.exp3.json &
python seed_sweep.py 3500 3 simulation_config.exp3.json &

