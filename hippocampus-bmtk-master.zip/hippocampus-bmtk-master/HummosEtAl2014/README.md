# hippocampus-bmtk

## Experiments
| No. | Experiment | Information |
| --- |:----------:| ----------- |
| 0   | **Pattern completion and separation** | This is the experiment presented in the *methods* section of the paper, where all patterns 1 (consists of 10 randomly selected EC neurons) is presented to the network for encoding for five trials, with LTP activated, and ACh set to high.  Followed by the presentation of patterns 1 through 11 with LTP inactivated and ACh set to the value assigned to the variable "Mods2".  The value of this variable can be set by editing the file Hipp.hoc and it controls the level of ACh during retrieval, to examine the effects of the neuromodulator on the dynamics of retrieval. |
| 1 | **Fear conditioning and extinction** | 
| 2 | **Learn two patterns and test retrieving one of them** | This is a modified protocol where the network learns both pattern 1 and pattern 11 interleaved in 10 trials.  Then retrieval is tested with the probe patterns that gradually morph from pattern 1 to pattern 11.  The results produced were similar To Experiment=0 and were not reported in the paper.
| 3 | **Testing network stability with increasing amounts of input** | **This is the main experiment from the paper examining network stability.**  An increasing number of EC neurons receive a stimulus of one action potential every 500 ms.  ACh is constant in this experiment and is set to the value assigned to the variable Mods2. |
| 4 | **Short experiment for network temporal dynamics** | This is a short experiment where 20 EC neurons receive an action potential at times zero and the response of CA3 pyramidal cells and well and inhibition are monitored (See figure 10D). |

## Code Analysis
**General steps**:
1. Load cell templates
2. Initialize Cells
3. Define Cell locations
4. Connect cells (based on *./Inputs/Synapses.txt*)
5. Randomly initialize cell voltage levels
6. Apply stimulus based on experiment number
7. Preset times that variables change values
8. Run experiment
9. Save output

### Hipp.hoc
 Main file to run the simulations and adjust parameters
 * Load Template.hoc
   * **IzhiCell_CA3**
   * **IzhiCell_GC**
   * **IzhiCell_EC**
   * **IzhiCell_OLM**
   * **IzhiCell_BC**
 * Load *ReadExperiments.hoc*
   * Load *./inputs/Experiment.txt*, values placed in
     * **ExpNo**
     * **Var1**
     * **Var2**
     * **Var3**
     * **Var4**
     * **Var5**
* Set **outpath**
   * (Default *./Outputs*)
   * **Specifies the folder path where the output files from the simulation will be stored.**  No graphs are produced by the Neuron code but rather output is stored in data files.
 * Set **ACHlevel** 
   * (Default 1)
   * This variable **determines the level of the neuromodulator Acetylcholine** during the experiment.  For **experiment 3**, and it determines the level of the neuromodulator for the whole experiment, whereas for **experiment 0**, it only determines the level during the retrieval phase.
 * Set **Experiment** number
   * (Default 3)
 * Set **expSig**
   * (Default "full")
   * a user defined unique string that gets incorporated into the names of the output files from the simulation, so that they can be easily identified as belonging to this experiment in MATLAB.
 * Set **rand**
   * Seed of rand is set to value in *seed.txt* Default: 9
 * **cvode** initialized
 * **fih** initialized
   * **FInitializeHandler(0,"Commands()")**
 * Load *protocol.hoc*
   * See section for initilizations
 * Define the following
   * **showNeurons** = 0
   * **ShowArea** = 1  
     * 1 for CA3 and 2 for DG
   * **diagnostics** = 0
   * **wACH** = .05 //.1
 * **EC** Cells
   * **inpTotal** = 30
   * **IzhiCell_EC** template
   * **inpCell** array for definition
   * **ECCells** list for storage
 * **CA3e** Cells
   * **excTotal** = 63
   * **IzhiCell_CA3** template
   * **excCell** array for definition
   * **CA3eCells** list for storage
 * **CA3o** Cells
   * **CA3oTotal** = 8
   * **IzhiCell_OLM** template
   * **CA3oCell** array for definition
   * **CA3oCells** list for storage
 * **CA3b** Cells
   * **CA3bTotal** = 8
   * **IzhiCell_BC** template
   * **CA3bCell** array for definition
   * **CA3bCells** list for storage
 * **DGg** Cells
   * **DGexcTotal** = 384
   * **IzhiCell_CG** template
   * **DGexcCell** array for definition
   * **DGgCells** list for storage
 * **DGh** Cells
   * **DGhTotal** = 32
   * **IzhiCell_OLM** template
   * **DGhCell** array for definition
   * **DGhCells** list for storage
 * **DGb** Cells
   * **DGbTotal** = 32
   * **IzhiCell_BC** template
   * **DGbCell** array for definition
   * **DGbCells** list for storage
* Load *Connect.hoc*
   * See section for initilizations
 * Randomly initialize cell soma v_init
 * Load *custominit.hoc*
   * initialize cvode with custom time markers
 * **
 * For experiments 0-5 load *StimuliTwoPatters.hoc*
   * Does something.
 * For experiment 3 load *StimuliStability.hoc*
   * Does something
 * For experiment 4 load *StimuliTempralEffect.hoc*
 * For experiment 5 load *StimuliResonance.hoc*
 * **
 * load *Record.hoc*
 * call Commands()
 * load *WriteOutput.hoc*
### Protocol.hoc
* define **Commands()** method

### Connect.hoc
* Load *MakeLocations.hoc*
   * See section for initilizations
 * **synM** (Matrix)
   * Loaded from *./Input/Synapses.txt*
 * **del** (Vector)
   * Stores delays
 * **Syn** (List)
   * Global Storage of synapses
 * **Con** (List)
   * Global Storage of connections
 * **Cells** (List)
   * Global storage of all Cells
 * **Locs** (List)
   * Global storage of all cell locations
 * **Totals** (Vector)
 * List of indices for each cell type connection in *./Inputs/Synapses.txt*
* **
 * **AddtoGlobal** method
 * **ConnectNeurons** method
 * **ConnectAreas** method
   * Arguments
     * preArea
     * postArea
     * pre2post
     * type
   * **par** = the column associated with pre/post area based on pre2post. This is the index column for this connection
 * **GetSynapses** method
 * **GetPre** method
 * **GetPreFromArea** method
 * ** 

### MakeLocations.hoc

Defines cell locations:

* **locEC** = new Matrix(3,**inpTotal**)}
* **locCA3** = new Matrix(3,**excTotal**)}
* **locCA3o** = new Matrix(3,**CA3oTotal**)}
* **locCA3b** = new Matrix(3,**CA3bTotal**)}
* **locDG** = new Matrix(3,**DGexcTotal**)}
* **locDGh** = new Matrix(3, **DGhTotal**)}
* **locDGb** = new Matrix(3, **DGbTotal**)}

Values are carfully defined to stay within bounds