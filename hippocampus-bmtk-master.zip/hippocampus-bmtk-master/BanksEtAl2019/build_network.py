from bmtk.builder.networks import NetworkBuilder

net = NetworkBuilder('ca3')
net.add_nodes(cell_name='poolosyn',
              model_type='biophysical',
              model_template='hoc:poolosyncell',
              morphology='blank.swc'
            )
net.build()
net.save_nodes(output_dir='network')
