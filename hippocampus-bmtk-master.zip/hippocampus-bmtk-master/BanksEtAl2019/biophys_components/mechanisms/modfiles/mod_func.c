#include <stdio.h>
#include "hocdec.h"
#define IMPORT extern __declspec(dllimport)
IMPORT int nrnmpi_myid, nrn_nobanner_;

extern void _ch_CavL_reg();
extern void _ch_CavN_reg();
extern void _ch_HCN_reg();
extern void _ch_HCNolm_reg();
extern void _ch_HCNp_reg();
extern void _ch_KCaS_reg();
extern void _ch_Kdrfast_reg();
extern void _ch_Kdrfastngf_reg();
extern void _ch_Kdrp_reg();
extern void _ch_Kdrslow_reg();
extern void _ch_KvA_reg();
extern void _ch_KvAdistp_reg();
extern void _ch_KvAngf_reg();
extern void _ch_KvAolm_reg();
extern void _ch_KvAproxp_reg();
extern void _ch_KvCaB_reg();
extern void _ch_KvGroup_reg();
extern void _ch_KvM_reg();
extern void _ch_Nav_reg();
extern void _ch_Navaxonp_reg();
extern void _ch_Navbis_reg();
extern void _ch_Navcck_reg();
extern void _ch_Navngf_reg();
extern void _ch_Navp_reg();
extern void _ch_leak_reg();

modl_reg(){
	//nrn_mswindll_stdio(stdin, stdout, stderr);
    if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," ch_CavL.mod");
fprintf(stderr," ch_CavN.mod");
fprintf(stderr," ch_HCN.mod");
fprintf(stderr," ch_HCNolm.mod");
fprintf(stderr," ch_HCNp.mod");
fprintf(stderr," ch_KCaS.mod");
fprintf(stderr," ch_Kdrfast.mod");
fprintf(stderr," ch_Kdrfastngf.mod");
fprintf(stderr," ch_Kdrp.mod");
fprintf(stderr," ch_Kdrslow.mod");
fprintf(stderr," ch_KvA.mod");
fprintf(stderr," ch_KvAdistp.mod");
fprintf(stderr," ch_KvAngf.mod");
fprintf(stderr," ch_KvAolm.mod");
fprintf(stderr," ch_KvAproxp.mod");
fprintf(stderr," ch_KvCaB.mod");
fprintf(stderr," ch_KvGroup.mod");
fprintf(stderr," ch_KvM.mod");
fprintf(stderr," ch_Nav.mod");
fprintf(stderr," ch_Navaxonp.mod");
fprintf(stderr," ch_Navbis.mod");
fprintf(stderr," ch_Navcck.mod");
fprintf(stderr," ch_Navngf.mod");
fprintf(stderr," ch_Navp.mod");
fprintf(stderr," ch_leak.mod");
fprintf(stderr, "\n");
    }
_ch_CavL_reg();
_ch_CavN_reg();
_ch_HCN_reg();
_ch_HCNolm_reg();
_ch_HCNp_reg();
_ch_KCaS_reg();
_ch_Kdrfast_reg();
_ch_Kdrfastngf_reg();
_ch_Kdrp_reg();
_ch_Kdrslow_reg();
_ch_KvA_reg();
_ch_KvAdistp_reg();
_ch_KvAngf_reg();
_ch_KvAolm_reg();
_ch_KvAproxp_reg();
_ch_KvCaB_reg();
_ch_KvGroup_reg();
_ch_KvM_reg();
_ch_Nav_reg();
_ch_Navaxonp_reg();
_ch_Navbis_reg();
_ch_Navcck_reg();
_ch_Navngf_reg();
_ch_Navp_reg();
_ch_leak_reg();
}
