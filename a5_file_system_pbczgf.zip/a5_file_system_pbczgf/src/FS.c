#include "dyn_array.h"
#include "bitmap.h"
#include "block_store.h"
#include "FS.h"

// You might find this handy.  I put it around unused parameters, but you should
// remove it before you submit. Just allows things to compile initially.
#define UNUSED(x) (void)(x)


#define number_inodes 256
#define inode_size 64
#define number_fd 256
#define fd_size 6	// any number as you see fit

#define folder_number_entries 31

// each inode represents a regular file or a directory file
struct inode 
{
    uint32_t vacantFile;    // this parameter is only for directory. Used as a bitmap denoting availibility of entries in a directory file.
    char owner[18];         // for alignment purpose only   

    char fileType;          // 'r' denotes regular file, 'd' denotes directory file

    size_t inodeNumber;			// for FS, the range should be 0-255
    size_t fileSize; 			  // the unit is in byte	
    size_t linkCount;

    // to realize the 16-bit addressing, pointers are acutally block numbers, rather than 'real' pointers.
    uint16_t directPointer[6];
    uint16_t indirectPointer[1];
    uint16_t doubleIndirectPointer;
};


struct fileDescriptor 
{
    uint8_t inodeNum;	// the inode # of the fd

    // usage, locate_order and locate_offset together locate the exact byte at which the cursor is 
    uint8_t usage; 		// inode pointer usage info. Only the lower 3 digits will be used. 1 for direct, 2 for indirect, 4 for dbindirect
    uint16_t locate_order;		// serial number or index of the block within direct, indirect, or dbindirect range
    uint16_t locate_offset;		// offset of the cursor within a block
};


struct directoryFile {
    char filename[127];
    uint8_t inodeNumber;
};


struct FS {
    block_store_t * BlockStore_whole;
    block_store_t * BlockStore_inode;
    block_store_t * BlockStore_fd;
};




/// Formats (and mounts) an FS file for use
/// \param fname The file to format
/// \return Mounted FS object, NULL on error
///
FS_t *fs_format(const char *path)
{
    if(path != NULL && strlen(path) != 0)
    {
        FS_t * ptr_FS = (FS_t *)calloc(1, sizeof(FS_t));	// get started
        ptr_FS->BlockStore_whole = block_store_create(path);				// pointer to start of a large chunck of memory

        // reserve the 1st block for bitmap of inode
        size_t bitmap_ID = block_store_allocate(ptr_FS->BlockStore_whole);
        //		printf("bitmap_ID = %zu\n", bitmap_ID);

        // 2rd - 5th block for inodes, 4 blocks in total
        size_t inode_start_block = block_store_allocate(ptr_FS->BlockStore_whole);
        //		printf("inode_start_block = %zu\n", inode_start_block);		
        for(int i = 0; i < 3; i++)
        {
            block_store_allocate(ptr_FS->BlockStore_whole);
            //			printf("all the way with block %zu\n", block_store_allocate(ptr_FS->BlockStore_whole));
        }

        // install inode block store inside the whole block store
        ptr_FS->BlockStore_inode = block_store_inode_create(block_store_Data_location(ptr_FS->BlockStore_whole) + bitmap_ID * BLOCK_SIZE_BYTES, block_store_Data_location(ptr_FS->BlockStore_whole) + inode_start_block * BLOCK_SIZE_BYTES);

        // the first inode is reserved for root dir
        block_store_sub_allocate(ptr_FS->BlockStore_inode);
        //		printf("first inode ID = %zu\n", block_store_sub_allocate(ptr_FS->BlockStore_inode));

        // update the root inode info.
        uint8_t root_inode_ID = 0;	// root inode is the first one in the inode table
        inode_t * root_inode = (inode_t *) calloc(1, sizeof(inode_t));
        //		printf("size of inode_t = %zu\n", sizeof(inode_t));
        root_inode->vacantFile = 0x00000000;
        root_inode->fileType = 'd';								
        root_inode->inodeNumber = root_inode_ID;
        root_inode->linkCount = 1;
        //		root_inode->directPointer[0] = root_data_ID;	// not allocate date block for it until it has a sub-folder or file
        block_store_inode_write(ptr_FS->BlockStore_inode, root_inode_ID, root_inode);		
        free(root_inode);

        // now allocate space for the file descriptors
        ptr_FS->BlockStore_fd = block_store_fd_create();

        return ptr_FS;
    }

    return NULL;	
}



///
/// Mounts an FS object and prepares it for use
/// \param fname The file to mount

/// \return Mounted FS object, NULL on error

///
FS_t *fs_mount(const char *path)
{
    if(path != NULL && strlen(path) != 0)
    {
        FS_t * ptr_FS = (FS_t *)calloc(1, sizeof(FS_t));	// get started
        ptr_FS->BlockStore_whole = block_store_open(path);	// get the chunck of data	

        // the bitmap block should be the 1st one
        size_t bitmap_ID = 0;

        // the inode blocks start with the 2nd block, and goes around until the 5th block, 4 in total
        size_t inode_start_block = 1;

        // attach the bitmaps to their designated place
        ptr_FS->BlockStore_inode = block_store_inode_create(block_store_Data_location(ptr_FS->BlockStore_whole) + bitmap_ID * BLOCK_SIZE_BYTES, block_store_Data_location(ptr_FS->BlockStore_whole) + inode_start_block * BLOCK_SIZE_BYTES);

        // since file descriptors are allocated outside of the whole blocks, we can simply reallocate space for it.
        ptr_FS->BlockStore_fd = block_store_fd_create();

        return ptr_FS;
    }

    return NULL;		
}




///
/// Unmounts the given object and frees all related resources
/// \param fs The FS object to unmount
/// \return 0 on success, < 0 on failure
///
int fs_unmount(FS_t *fs)
{
    if(fs != NULL)
    {	
        block_store_inode_destroy(fs->BlockStore_inode);

        block_store_destroy(fs->BlockStore_whole);
        block_store_fd_destroy(fs->BlockStore_fd);

        free(fs);
        return 0;
    }
    return -1;
}


// check if the input filename is valid or not
bool isValidFileName(const char *filename)
{
    if(!filename || strlen(filename) == 0 || strlen(filename) > 31)		// some "big" number as you wish
    {
        return false;
    }

    // define invalid characters might be contained in filenames
    char *invalidCharacters = "!@#$%^&*?\"";
    int i = 0;
    int len = strlen(invalidCharacters);
    for( ; i < len; i++)
    {
        if(strchr(filename, invalidCharacters[i]) != NULL)
        {
            return false;
        }
    }
    return true;
}



// use str_split to decompose the input string into filenames along the path, '/' as delimiter
char** str_split(char* a_str, const char a_delim, size_t * count)
{
    if(*a_str != '/')
    {
        return NULL;
    }
    char** result    = 0;
    char* tmp        = a_str;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = '\0';

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            (*count)++;
        }
        tmp++;
    }

    result = (char**)calloc(1, sizeof(char*) * (*count));
    for(size_t i = 0; i < (*count); i++)
    {
        *(result + i) = (char*)calloc(1, 200);
    }

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, delim);

        while (token)
        {
            strcpy(*(result + idx++), token);
            //    *(result + idx++) = strdup(token);
            token = strtok(NULL, delim);
        }

    }
    return result;
}



///
/// Creates a new file at the specified location
///   Directories along the path that do not exist are not created
/// \param fs The FS containing the file
/// \param path Absolute path to file to create
/// \param type Type of file to create (regular/directory)
/// \return 0 on success, < 0 on failure
///
int fs_create(FS_t *fs, const char *path, file_t type)
{
    if(fs != NULL && path != NULL && strlen(path) != 0 && (type == FS_REGULAR || type == FS_DIRECTORY))
    {
        char* copy_path = (char*)calloc(1, 65535);
        strcpy(copy_path, path);
        char** tokens;		// tokens are the directory names along the path. The last one is the name for the new file or dir
        size_t count = 0;
        tokens = str_split(copy_path, '/', &count);
        free(copy_path);
        if(tokens == NULL)
        {
            return -1;
        }

        // let's check if the filenames are valid or not
        for(size_t n = 0; n < count; n++)
        {	
            if(isValidFileName(*(tokens + n)) == false)
            {
                // before any return, we need to free tokens, otherwise memory leakage
                for (size_t i = 0; i < count; i++)
                {
                    free(*(tokens + i));
                }
                free(tokens);
                return -1;
            }
        }

        size_t parent_inode_ID = 0;	// start from the 1st inode, ie., the inode for root directory
        // first, let's find the parent dir
        size_t indicator = 0;

        // we declare parent_inode and parent_data here since it will still be used after the for loop
        directoryFile_t * parent_data = (directoryFile_t *)calloc(1, BLOCK_SIZE_BYTES);
        inode_t * parent_inode = (inode_t *) calloc(1, sizeof(inode_t));	

        for(size_t i = 0; i < count - 1; i++)
        {
            block_store_inode_read(fs->BlockStore_inode, parent_inode_ID, parent_inode);	// read out the parent inode
            // in case file and dir has the same name
            if(parent_inode->fileType == 'd')
            {
                block_store_read(fs->BlockStore_whole, parent_inode->directPointer[0], parent_data);

                for(int j = 0; j < folder_number_entries; j++)
                {
                    if( ((parent_inode->vacantFile >> j) & 1) == 1 && strcmp((parent_data + j) -> filename, *(tokens + i)) == 0 )
                    {
                        parent_inode_ID = (parent_data + j) -> inodeNumber;
                        indicator++;
                    }					
                }
            }					
        }
        //		printf("indicator = %zu\n", indicator);
        //		printf("parent_inode_ID = %lu\n", parent_inode_ID);

        // read out the parent inode
        block_store_inode_read(fs->BlockStore_inode, parent_inode_ID, parent_inode);
        if(indicator == count - 1 && parent_inode->fileType == 'd')
        {
            // same file or dir name in the same path is intolerable
            for(int m = 0; m < folder_number_entries; m++)
            {
                // rid out the case of existing same file or dir name
                if( ((parent_inode->vacantFile >> m) & 1) == 1)
                {
                    // before read out parent_data, we need to make sure it does exist!
                    block_store_read(fs->BlockStore_whole, parent_inode->directPointer[0], parent_data);
                    if( strcmp((parent_data + m) -> filename, *(tokens + count - 1)) == 0 )
                    {
                        free(parent_data);
                        free(parent_inode);	
                        // before any return, we need to free tokens, otherwise memory leakage
                        for (size_t i = 0; i < count; i++)
                        {
                            free(*(tokens + i));
                        }
                        free(tokens);
                        return -1;											
                    }
                }
            }	

            // cannot declare k inside for loop, since it will be used later.
            int k = 0;
            for( ; k < folder_number_entries; k++)
            {
                if( ((parent_inode->vacantFile >> k) & 1) == 0 )
                    break;
            }

            // if k == 0, then we have to declare a new parent data block
            //			printf("k = %d\n", k);
            if(k == 0)
            {
                size_t parent_data_ID = block_store_allocate(fs->BlockStore_whole);
                //					printf("parent_data_ID = %zu\n", parent_data_ID);
                if(parent_data_ID < BLOCK_STORE_AVAIL_BLOCKS)
                {
                    parent_inode->directPointer[0] = parent_data_ID;
                }
                else
                {
                    free(parent_inode);
                    free(parent_data);
                    // before any return, we need to free tokens, otherwise memory leakage
                    for (size_t i = 0; i < count; i++)
                    {
                        free(*(tokens + i));
                    }
                    free(tokens);
                    return -1;												
                }
            }

            if(k < folder_number_entries)	// k == folder_number_entries means this directory is full
            {
                size_t child_inode_ID = block_store_sub_allocate(fs->BlockStore_inode);
                // printf("new child_inode_ID = %zu\n", child_inode_ID);
                // ugh, inodes are used up
                if(child_inode_ID == SIZE_MAX)
                {
                    free(parent_data);
                    free(parent_inode);
                    // before any return, we need to free tokens, otherwise memory leakage
                    for (size_t i = 0; i < count; i++)
                    {
                        free(*(tokens + i));
                    }
                    free(tokens);
                    return -1;	
                }

                // wow, at last, we make it!				
                // update the parent inode
                parent_inode->vacantFile |= (1 << k);
                // in the following cases, we should allocate parent data first: 
                // 1)the parent dir is not the root dir; 
                // 2)the file or dir to create is to be the 1st in the parent dir

                block_store_inode_write(fs->BlockStore_inode, parent_inode_ID, parent_inode);	

                // update the parent directory file block
                block_store_read(fs->BlockStore_whole, parent_inode->directPointer[0], parent_data);
                strcpy((parent_data + k)->filename, *(tokens + count - 1));
                //				printf("the newly created file's name is: %s\n", (parent_data + k)->filename);
                (parent_data + k)->inodeNumber = child_inode_ID;
                block_store_write(fs->BlockStore_whole, parent_inode->directPointer[0], parent_data);

                // update the newly created inode
                inode_t * child_inode = (inode_t *) calloc(1, sizeof(inode_t));
                child_inode->vacantFile = 0;
                if(type == FS_REGULAR)
                {
                    child_inode->fileType = 'r';
                }
                else if(type == FS_DIRECTORY)
                {
                    child_inode->fileType = 'd';
                }	

                child_inode->inodeNumber = child_inode_ID;
                child_inode->fileSize = 0;
                child_inode->linkCount = 1;
                block_store_inode_write(fs->BlockStore_inode, child_inode_ID, child_inode);

                //				printf("after creation, parent_inode->vacantFile = %d\n", parent_inode->vacantFile);



                // free the temp space
                free(parent_inode);
                free(parent_data);
                free(child_inode);
                // before any return, we need to free tokens, otherwise memory leakage
                for (size_t i = 0; i < count; i++)
                {
                    free(*(tokens + i));
                }
                free(tokens);					
                return 0;
            }				
        }
        // before any return, we need to free tokens, otherwise memory leakage
        for (size_t i = 0; i < count; i++)
        {
            free(*(tokens + i));
        }
        free(tokens); 
        free(parent_inode);	
        free(parent_data);
    }
    return -1;
}



///
/// Opens the specified file for use
///   R/W position is set to the beginning of the file (BOF)
///   Directories cannot be opened
/// \param fs The FS containing the file
/// \param path path to the requested file
/// \return file descriptor to the requested file, < 0 on error
///
int fs_open(FS_t *fs, const char *path)
{
    if(fs != NULL && path != NULL && strlen(path) != 0)
    {
        char* copy_path = (char*)calloc(1, 65535);
        strcpy(copy_path, path);
        char** tokens;		// tokens are the directory names along the path. The last one is the name for the new file or dir
        size_t count = 0;
        tokens = str_split(copy_path, '/', &count);
        free(copy_path);
        if(tokens == NULL)
        {
            return -1;
        }

        // let's check if the filenames are valid or not
        for(size_t n = 0; n < count; n++)
        {	
            if(isValidFileName(*(tokens + n)) == false)
            {
                // before any return, we need to free tokens, otherwise memory leakage
                for (size_t i = 0; i < count; i++)
                {
                    free(*(tokens + i));
                }
                free(tokens);
                return -1;
            }
        }	

        size_t parent_inode_ID = 0;	// start from the 1st inode, ie., the inode for root directory
        // first, let's find the parent dir
        size_t indicator = 0;

        inode_t * parent_inode = (inode_t *) calloc(1, sizeof(inode_t));
        directoryFile_t * parent_data = (directoryFile_t *)calloc(1, BLOCK_SIZE_BYTES);			

        // locate the file
        for(size_t i = 0; i < count; i++)
        {		
            block_store_inode_read(fs->BlockStore_inode, parent_inode_ID, parent_inode);	// read out the parent inode
            if(parent_inode->fileType == 'd')
            {
                block_store_read(fs->BlockStore_whole, parent_inode->directPointer[0], parent_data);
                //printf("parent_inode->vacantFile = %d\n", parent_inode->vacantFile);
                for(int j = 0; j < folder_number_entries; j++)
                {
                    //printf("(parent_data + j) -> filename = %s\n", (parent_data + j) -> filename);
                    if( ((parent_inode->vacantFile >> j) & 1) == 1 && strcmp((parent_data + j) -> filename, *(tokens + i)) == 0 )
                    {
                        parent_inode_ID = (parent_data + j) -> inodeNumber;
                        indicator++;
                    }					
                }
            }					
        }		
        free(parent_data);			
        free(parent_inode);	
        //printf("indicator = %zu\n", indicator);
        //printf("count = %zu\n", count);
        // now let's open the file
        if(indicator == count)
        {
            size_t fd_ID = block_store_sub_allocate(fs->BlockStore_fd);
            //printf("fd_ID = %zu\n", fd_ID);
            // it could be possible that fd runs out
            if(fd_ID < number_fd)
            {
                size_t file_inode_ID = parent_inode_ID;
                inode_t * file_inode = (inode_t *) calloc(1, sizeof(inode_t));
                block_store_inode_read(fs->BlockStore_inode, file_inode_ID, file_inode);	// read out the file inode	

                // it's too bad if file to be opened is a dir 
                if(file_inode->fileType == 'd')
                {
                    free(file_inode);
                    // before any return, we need to free tokens, otherwise memory leakage
                    for (size_t i = 0; i < count; i++)
                    {
                        free(*(tokens + i));
                    }
                    free(tokens);
                    return -1;
                }

                // assign a file descriptor ID to the open behavior
                fileDescriptor_t * fd = (fileDescriptor_t *)calloc(1, sizeof(fileDescriptor_t));
                fd->inodeNum = file_inode_ID;
                fd->usage = 1;
                fd->locate_order = 0; // R/W position is set to the beginning of the file (BOF)
                fd->locate_offset = 0;
                block_store_fd_write(fs->BlockStore_fd, fd_ID, fd);

                free(file_inode);
                free(fd);
                // before any return, we need to free tokens, otherwise memory leakage
                for (size_t i = 0; i < count; i++)
                {
                    free(*(tokens + i));
                }
                free(tokens);			
                return fd_ID;
            }	
        }
        // before any return, we need to free tokens, otherwise memory leakage
        for (size_t i = 0; i < count; i++)
        {
            free(*(tokens + i));
        }
        free(tokens);
    }
    return -1;
}


///
/// Closes the given file descriptor
/// \param fs The FS containing the file
/// \param fd The file to close
/// \return 0 on success, < 0 on failure
///
int fs_close(FS_t *fs, int fd)
{
    if(fs != NULL && fd >=0 && fd < number_fd)
    {
        // first, make sure this fd is in use
        if(block_store_sub_test(fs->BlockStore_fd, fd))
        {
            block_store_sub_release(fs->BlockStore_fd, fd);
            return 0;
        }	
    }
    return -1;
}



///
/// Populates a dyn_array with information about the files in a directory
///   Array contains up to 15 file_record_t structures
/// \param fs The FS containing the file
/// \param path Absolute path to the directory to inspect
/// \return dyn_array of file records, NULL on error
///
dyn_array_t *fs_get_dir(FS_t *fs, const char *path)
{
    if(fs != NULL && path != NULL && strlen(path) != 0)
    {	
        char* copy_path = (char*)malloc(200);
        strcpy(copy_path, path);
        char** tokens;		// tokens are the directory names along the path. The last one is the name for the new file or dir
        size_t count = 0;
        tokens = str_split(copy_path, '/', &count);
        free(copy_path);

        if(strlen(*tokens) == 0)
        {
            // a spcial case: only a slash, no dir names
            count -= 1;
        }
        else
        {
            for(size_t n = 0; n < count; n++)
            {	
                if(isValidFileName(*(tokens + n)) == false)
                {
                    // before any return, we need to free tokens, otherwise memory leakage
                    for (size_t i = 0; i < count; i++)
                    {
                        free(*(tokens + i));
                    }
                    free(tokens);		
                    return NULL;
                }
            }			
        }		

        // search along the path and find the deepest dir
        size_t parent_inode_ID = 0;	// start from the 1st inode, ie., the inode for root directory
        // first, let's find the parent dir
        size_t indicator = 0;

        inode_t * parent_inode = (inode_t *) calloc(1, sizeof(inode_t));
        directoryFile_t * parent_data = (directoryFile_t *)calloc(1, BLOCK_SIZE_BYTES);
        for(size_t i = 0; i < count; i++)
        {
            block_store_inode_read(fs->BlockStore_inode, parent_inode_ID, parent_inode);	// read out the parent inode
            // in case file and dir has the same name. But from the test cases we can see, this case would not happen
            if(parent_inode->fileType == 'd')
            {			
                block_store_read(fs->BlockStore_whole, parent_inode->directPointer[0], parent_data);
                for(int j = 0; j < folder_number_entries; j++)
                {
                    if( ((parent_inode->vacantFile >> j) & 1) == 1 && strcmp((parent_data + j) -> filename, *(tokens + i)) == 0 )
                    {
                        parent_inode_ID = (parent_data + j) -> inodeNumber;
                        indicator++;
                    }					
                }	
            }					
        }	
        free(parent_data);
        free(parent_inode);	

        // now let's enumerate the files/dir in it
        if(indicator == count)
        {
            inode_t * dir_inode = (inode_t *) calloc(1, sizeof(inode_t));
            block_store_inode_read(fs->BlockStore_inode, parent_inode_ID, dir_inode);	// read out the file inode			
            if(dir_inode->fileType == 'd')
            {
                // prepare the data to be read out
                directoryFile_t * dir_data = (directoryFile_t *)calloc(1, BLOCK_SIZE_BYTES);
                block_store_read(fs->BlockStore_whole, dir_inode->directPointer[0], dir_data);

                // prepare the dyn_array to hold the data
                dyn_array_t * dynArray = dyn_array_create(15, sizeof(file_record_t), NULL);

                for(int j = 0; j < folder_number_entries; j++)
                {
                    if( ((dir_inode->vacantFile >> j) & 1) == 1 )
                    {
                        file_record_t* fileRec = (file_record_t *)calloc(1, sizeof(file_record_t));
                        strcpy(fileRec->name, (dir_data + j) -> filename);

                        // to know fileType of the member in this dir, we have to refer to its inode
                        inode_t * member_inode = (inode_t *) calloc(1, sizeof(inode_t));
                        block_store_inode_read(fs->BlockStore_inode, (dir_data + j) -> inodeNumber, member_inode);
                        if(member_inode->fileType == 'd')
                        {
                            fileRec->type = FS_DIRECTORY;
                        }
                        else if(member_inode->fileType == 'f')
                        {
                            fileRec->type = FS_REGULAR;
                        }

                        // now insert the file record into the dyn_array
                        dyn_array_push_front(dynArray, fileRec);
                        free(fileRec);
                        free(member_inode);
                    }					
                }
                free(dir_data);
                free(dir_inode);
                // before any return, we need to free tokens, otherwise memory leakage
                if(strlen(*tokens) == 0)
                {
                    // a spcial case: only a slash, no dir names
                    count += 1;
                }
                for (size_t i = 0; i < count; i++)
                {
                    free(*(tokens + i));
                }
                free(tokens);	
                return(dynArray);
            }
            free(dir_inode);
        }
        // before any return, we need to free tokens, otherwise memory leakage
        if(strlen(*tokens) == 0)
        {
            // a spcial case: only a slash, no dir names
            count += 1;
        }
        for (size_t i = 0; i < count; i++)
        {
            free(*(tokens + i));
        }
        free(tokens);	
    }
    return NULL;
}
off_t fs_seek(FS_t *fs, int fd, off_t offset, seek_t whence)
{
    UNUSED(fs);
    UNUSED(fd);
    UNUSED(offset);
    UNUSED(whence);
    return 0;
}

//This is just a helper function that updates the metadata for the
//file descriptors and the inode objects.
//All it does is writes the given obects.
void update_metadata(FS_t *fs, int fd, inode_t * inode, fileDescriptor_t * file_descriptor, size_t bytes_written)
{
    inode -> fileSize += bytes_written;
    block_store_inode_write(fs -> BlockStore_inode, file_descriptor -> inodeNum, inode);
    block_store_fd_write(fs -> BlockStore_fd, fd, file_descriptor);

}

void read_to_buffer(void * read_buffer, void * dst, size_t * byte_offset, size_t * bytes_to_read, 
                       fileDescriptor_t * file_descriptor)
{
    if ((*bytes_to_read) >= BLOCK_SIZE_BYTES)
    {
        file_descriptor -> locate_order++;
        memcpy(dst + (*byte_offset), read_buffer , BLOCK_SIZE_BYTES);
        (*byte_offset) += BLOCK_SIZE_BYTES;
        (*bytes_to_read) -= BLOCK_SIZE_BYTES;
    }
    else
    {
        file_descriptor -> locate_offset+=(*bytes_to_read);
        memcpy(dst + (*byte_offset), read_buffer , (*bytes_to_read));
        (*byte_offset) += (*bytes_to_read);
        (*bytes_to_read) = 0;
    }
}

ssize_t fs_read(FS_t *fs, int fd, void *dst, size_t nbyte)
{
        if(nbyte == 0)
        return 0;

    if(!fs || fd < 0 || !dst)
        return -1;

    //Check to make sure that the given file descriptor is open.
    if(!block_store_sub_test(fs->BlockStore_fd, fd))
        return -1;

    //The very first thing that we probably need to do is to get the files inode.
    inode_t file_inode;
    fileDescriptor_t file_descriptor;
    block_store_fd_read(fs -> BlockStore_fd, fd, &file_descriptor);

    //Now we have access to the file inode and its fd object.
    //We could check that the inode isnt orphaned but I dont think thats required.
    //Read the inode based on the fd.
    block_store_inode_read(fs->BlockStore_inode, file_descriptor.inodeNum, &file_inode);

    bool done = false;
    //Now we need to attempt to read the file.
    //Basically we just need to read in block size chunks to the buffer.
    //First we need to attempt to read all the direct pointers.
    //Then we need to go thorough the indirect and double indirect pointers as well.
    //We probably need to update the file location pointers but im not sure we need to do that.

    file_descriptor.locate_order = 0;
    file_descriptor.locate_offset = 0;
    size_t bytes_to_read = nbyte;
    size_t byte_offset = 0;
    //Calloc a buffer so that its garenteed that what we are reading will fit perfectly 
    //in a block.
    uint8_t * read_buffer = calloc(BLOCK_SIZE_BYTES,1);

    //First try to use up the direct pointers.
    for(int i = 0; i < 6 && bytes_to_read != 0; ++i)
    {
        if(bytes_to_read != 0) 
        {
            //read to buffer.
            block_store_read(fs -> BlockStore_whole, file_inode.directPointer[i], read_buffer);

            read_to_buffer(dst, read_buffer, &byte_offset, &bytes_to_read, &file_descriptor);
        }
        else
        {
            
            //We are done we read everything.
            //Update metadata and return.
            update_metadata(fs, fd, &file_inode, &file_descriptor, nbyte);
            done = true;
            break;
        }
    }

    if(!done)
    {

        //Now lets attempt to use up all the inderect pointers and read data
        uint16_t indirect_buffer[BLOCK_SIZE_BYTES/2];
        block_store_read(fs -> BlockStore_whole, file_inode.directPointer[0], indirect_buffer);

        //Iterate through each pointer.
        for(size_t indirect_offset = 0; indirect_offset < BLOCK_STORE_NUM_BYTES/2; indirect_offset++)
        {
            if(bytes_to_read != 0)
            {
                //read to buffer.
                block_store_read(fs -> BlockStore_whole, indirect_buffer[indirect_offset], read_buffer);

                read_to_buffer(dst, read_buffer, &byte_offset, &bytes_to_read, &file_descriptor);
            }
            else
            {
                //We are done! update metadata and leave.
                
                //We are done we wrote everything.
                //Update metadata and return.
                update_metadata(fs, fd, &file_inode, &file_descriptor, nbyte);
                
                done = true;
                break;
            }
        }
    }

    if(!done)
    {

        //Now lets attempt to use up all the pointers in the the next block of pointers.
        uint16_t dindirect_buffer[BLOCK_SIZE_BYTES/2];
        block_store_read(fs -> BlockStore_whole, file_inode.doubleIndirectPointer, dindirect_buffer);

        //Iterate through each pointer.
        for(size_t dindirect_offset = 0; dindirect_offset < BLOCK_STORE_NUM_BYTES/2 && !done; dindirect_offset++)
        {
            //Now lets attempt to use up all the inderect pointers and write data
            uint16_t indirect_buffer[BLOCK_SIZE_BYTES/2];
            block_store_read(fs -> BlockStore_whole, dindirect_buffer[dindirect_offset], indirect_buffer);

            //Iterate through each pointer.
            for(size_t indirect_offset = 0; indirect_offset < BLOCK_STORE_NUM_BYTES/2 && !done; indirect_offset++)
            {
                
                if(bytes_to_read != 0)
                {
                    //read to buffer.
                    block_store_read(fs -> BlockStore_whole, indirect_buffer[indirect_offset], read_buffer);

                    read_to_buffer(dst, read_buffer, &byte_offset, &bytes_to_read, &file_descriptor);
                    
                }
                else
                {
                    //Update metadata and return.
                    update_metadata(fs, fd, &file_inode, &file_descriptor, nbyte);
                    
                    done = true;
                    break;
                }
            }

        }

    }

    return nbyte;
}


void write_to_buffer(void * write_buffer, const void * src, size_t * byte_offset, size_t * bytes_to_write, 
                       fileDescriptor_t * file_descriptor)
{
    if ((*bytes_to_write) >= BLOCK_SIZE_BYTES)
    {
        file_descriptor -> locate_order++;
        memcpy(write_buffer, src + (*byte_offset), BLOCK_SIZE_BYTES);
        (*byte_offset) += BLOCK_SIZE_BYTES;
        (*bytes_to_write) -= BLOCK_SIZE_BYTES;
    }
    else
    {
        file_descriptor -> locate_offset+=(*bytes_to_write);
        memcpy(write_buffer, src + (*byte_offset), (*bytes_to_write));
        (*byte_offset) += (*bytes_to_write);
        (*bytes_to_write) = 0;
    }
}

ssize_t fs_write(FS_t *fs, int fd, const void *src, size_t nbyte)
{
    if(nbyte == 0)
        return 0;

    if(!fs || fd < 0 || !src)
        return -1;

    //Check to make sure that the given file descriptor is open.
    if(!block_store_sub_test(fs->BlockStore_fd, fd))
        return -1;

    //The very first thing that we probably need to do is to 


    //Get the files inode.
    inode_t file_inode;
    fileDescriptor_t file_descriptor;
    block_store_fd_read(fs -> BlockStore_fd, fd, &file_descriptor);

    //Now we have access to the file inode and its fd object.
    //We could check that the inode isnt orphaned but I dont think thats required.
    //Read the inode based on the fd.
    block_store_inode_read(fs->BlockStore_inode, file_descriptor.inodeNum, &file_inode);

    bool done = false;
    //Now we need to attempt to write the file.
    //Basically we just need to write in block size chunks.
    //First we need to attempt to write all the direct pointers.
    //Then we need to go thorough the indirect and double indirect pointers as well.
    //We probably need to update the file location pointers but im not sure we need to do that.

    file_descriptor.locate_order = 0;
    file_descriptor.locate_offset = 0;
    size_t bytes_to_write = nbyte;
    size_t byte_offset = 0;
    size_t block_pointer;
    //Calloc a buffer so that its garenteed that what we are writting will fit perfectly 
    //in a block.
    uint8_t * write_buffer = calloc(BLOCK_SIZE_BYTES,1);

    //First try to use up the direct pointers.
    for(int i = 0; i < 6 && bytes_to_write != 0; ++i)
    {
        
        if(bytes_to_write != 0) 
        {
            //Need to request the current block to write to.
            block_pointer = block_store_allocate(fs ->BlockStore_whole);
            if (block_pointer == SIZE_MAX)
            {
                free(write_buffer);
                //The whole device is full.
                return byte_offset;
            }
            file_inode.directPointer[i] = block_pointer;

            //Write to buffer.
            write_to_buffer(write_buffer, src, &byte_offset, &bytes_to_write, &file_descriptor);

            //Write a whole block.
            block_store_write(fs -> BlockStore_whole, file_inode.directPointer[i], write_buffer);

        }
        else
        {
            //Update further metadata.
            file_inode.linkCount += (i + 1);
            
            //We are done we wrote everything.
            //Update metadata and return.
            update_metadata(fs, fd, &file_inode, &file_descriptor, nbyte);
            done = true;
            break;
        }
    }

    if(!done)
    {
        //We still have bytes to write left. Lets try and look at the indirect pointer now.
        //Attempt to allocate the indirect block. 
        block_pointer = block_store_allocate(fs ->BlockStore_whole);
        if (block_pointer == SIZE_MAX)
        {
            free(write_buffer);
            //The whole device is full.
            return byte_offset;
        }
        file_inode.indirectPointer[0] = block_pointer;

        //Now lets attempt to use up all the inderect pointers and write data
        uint16_t * indirect_buffer = calloc(BLOCK_STORE_NUM_BYTES, 1);

        //Iterate through each pointer.
        for(size_t indirect_offset = 0; indirect_offset < BLOCK_STORE_NUM_BYTES/2; indirect_offset++)
        {
            //Okay now we need to request another block.
            block_pointer = block_store_allocate(fs -> BlockStore_whole);

            //Check if we've run out of space.
            if(block_pointer == SIZE_MAX)
            {
                //Write the inderect buffer as of now.
                block_store_write(fs -> BlockStore_whole, file_inode.indirectPointer[0], indirect_buffer);
                free(write_buffer);
                free(indirect_buffer);

                return byte_offset;
            }

            //Store the pointer in the inderect buffer.
            indirect_buffer[indirect_offset] = block_pointer;

            if(bytes_to_write != 0)
            {
                //Write to the buffer.
                write_to_buffer(write_buffer, src, &byte_offset, &bytes_to_write, &file_descriptor);
                
                //Now we need to actually write to that block we just requested.
                block_store_write(fs -> BlockStore_whole, block_pointer, write_buffer);
            }
            else
            {
                //We are done! update metadata and leave.

                //Update further metadata.
                file_inode.linkCount += (indirect_offset + 1);
                
                //We are done we wrote everything.
                //Update metadata and return.
                update_metadata(fs, fd, &file_inode, &file_descriptor, nbyte);
                
                done = true;
                break;
            }
        }

        //Write the inderect pointer buffer when done!
        block_store_write(fs -> BlockStore_whole, file_inode.indirectPointer[0], indirect_buffer);
        
        //Free inderect pointer.
        free(indirect_buffer);

    }

    if(!done)
    {
        //We still arent done?? This means we need to go to the double indirect pointer.
        block_pointer = block_store_allocate(fs ->BlockStore_whole);
        if (block_pointer == SIZE_MAX)
        {
            free(write_buffer);
            //The whole device is full.
            return byte_offset;
        }
        file_inode.doubleIndirectPointer = block_pointer;

        //Now lets attempt to use up all the pointers in the the next block of pointers.
        uint16_t * dindirect_buffer = calloc(BLOCK_STORE_NUM_BYTES, 1);

        //Iterate through each pointer.
        for(size_t dindirect_offset = 0; dindirect_offset < BLOCK_STORE_NUM_BYTES/2 && !done; dindirect_offset++)
        {
            //Okay now we need to request another block.
            block_pointer = block_store_allocate(fs -> BlockStore_whole);

            //Check if we've run out of space.
            if(block_pointer == SIZE_MAX)
            {
                //Write the inderect buffer as of now.
                block_store_write(fs -> BlockStore_whole, file_inode.doubleIndirectPointer, dindirect_buffer);
                free(write_buffer);
                free(dindirect_buffer);

                return byte_offset;
            }

            //Store the pointer in the double indirect buffer.
            dindirect_buffer[dindirect_offset] = block_pointer;

            //Okay now we need to allocate the space for the *indirect* pointers pointed to from here
            block_pointer = block_store_allocate(fs ->BlockStore_whole);
            if (block_pointer == SIZE_MAX)
            {
                free(write_buffer);
                //The whole device is full.
                return byte_offset;
            }
            dindirect_buffer[dindirect_offset] = block_pointer;

            //Now lets attempt to use up all the inderect pointers and write data
            uint16_t * indirect_buffer = calloc(BLOCK_STORE_NUM_BYTES, 1);

            //Iterate through each pointer.
            for(size_t indirect_offset = 0; indirect_offset < BLOCK_STORE_NUM_BYTES/2 && !done; indirect_offset++)
            {
                //Okay now we need to request another block.
                block_pointer = block_store_allocate(fs -> BlockStore_whole);

                //Check if we've run out of space.
                if(block_pointer == SIZE_MAX)
                {
                    //Write the inderect buffer as of now.
                    block_store_write(fs -> BlockStore_whole, dindirect_buffer[dindirect_offset], indirect_buffer);

                    //Write the double inderect buffer.
                    block_store_write(fs -> BlockStore_whole, file_inode.doubleIndirectPointer, dindirect_buffer);
                    free(write_buffer);
                    free(indirect_buffer);

                    return byte_offset;
                }

                //Store the pointer in the double indirect buffer.
                indirect_buffer[indirect_offset] = block_pointer;

                if(bytes_to_write != 0)
                {
                    //Write to the buffer.
                    write_to_buffer(write_buffer, src, &byte_offset, &bytes_to_write, &file_descriptor);
                    
                    //Now we need to actually write to that block we just requested.
                    block_store_write(fs -> BlockStore_whole, block_pointer, write_buffer);
                }
                else
                {
                    //We are done! update metadata and leave.

                    //Update further metadata.
                    file_inode.linkCount += (indirect_offset + 1) + dindirect_offset * (BLOCK_STORE_NUM_BYTES/2);
                    
                    //We are done we wrote everything.
                    //Update metadata and return.
                    update_metadata(fs, fd, &file_inode, &file_descriptor, nbyte);
                    
                    done = true;
                    break;
                }
            }

            //Write the inderect pointer buffer when done!
            block_store_write(fs -> BlockStore_whole, dindirect_buffer[dindirect_offset], indirect_buffer);
            
            //Free inderect pointer.
            free(indirect_buffer);

        }
        //Write the inderect pointer buffer when done!
        block_store_write(fs -> BlockStore_whole, file_inode.doubleIndirectPointer, dindirect_buffer);
        
        //Free inderect pointer.
        free(dindirect_buffer);

    }

    //Free up the buffer.
    free(write_buffer);

    return nbyte;
}

int fs_remove(FS_t *fs, const char *path)
{
    UNUSED(fs);
    UNUSED(path);
    return 0;
}

int fs_move(FS_t *fs, const char *src, const char *dst)
{
    UNUSED(fs);
    UNUSED(src);
    UNUSED(dst);
    return 0;
}

int fs_link(FS_t *fs, const char *src, const char *dst)
{
    UNUSED(fs);
    UNUSED(src);
    UNUSED(dst);
    return 0;
}
