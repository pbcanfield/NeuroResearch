% function [coh, SpikeCount] = DrawThetaMesh(OutPath, expSig, input, AChVals, seeds, expType , tstop)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%%% 
close all; clear all; clc;
results = [];
ResultsSTD= [];

for Grand= [1,2,4,5]
    %0:0
%% function stuff
AChVals = Grand;
% NoECinput = 15;

% if AChVals == 0; NoECinput = 110; end
% if AChVals == 2; NoECinput = 20; end
% if AChVals ==1; NoECinput = 50; end
% input = [4];
experiments = [12, 13, 15, 35, 36];
experiments = [15,15,15,15,15]
experiments = [15,15,15,15,15] +20

seeds = 1:5;

% current injections titration
ACh = struct();
ACh.i = 3;
%              -full   -OLM  -SFA   --Both    -+-RC
ACh0 =     [     -2,      -2,      0,      2,      2];

ACh1 =     [     4,      4.5,      4,      8.3,      6.5];
                        %4.5                       6.5
ACh2 =     [     5,      8.6,    4,      13,     11];
                 %       %4.5       %      6.5 either 11or 12
iValues = [ACh0; ACh1; ACh2];
input_i = 1 ; %  /100
iValues = zeros(6, 5) + input_i; 
iValues(:, 2) = 6;
iValues(:, 3) = 7;
iValues(:, 4) = 8;
iValues(:, 5) = 9;
% iValues(:, 6) = 70;

tstop = 5000;
% windowLen = 2048;
OutPath= '..\..\Outputs\Review\';

expSig = 'AChReview';
expSig = 'hReview';
% expSig = 'iReview';
    

i = 2;
 cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];

not_found = 0;
fileNames = dir([OutPath '*' expSig  'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};

% Define structures to store values
PrefFreqS = struct();
PrefFreq = [];
FireRateS = struct();
FireRate = [];
RelaThetaS= struct();
RelaTheta= [];
allPx = [];

% for ii = 1:length(input)
    for ei = 1:length(experiments)
        for ai = 1:length(AChVals)
ii = 1;
pxxSeed = [];

% resets here so that it gathers information from all seeds        
            dist = struct(); 
            stmean = struct();
            utData = struct();
            seedGather = [];
            pxxs = [];
            
        for si = 1:length(seeds)
%             if experiments(ei)==16 
%             Basename = [ num2str(NoECinput) '-' num2str(seeds(si)) '-' num2str(experiments(ei)) '-' num2str(AChVals(ai)) expSig];
%             else
                Basename = [ num2str(iValues(Grand+1, ei)) '-' num2str(seeds(si)) '-' num2str(experiments(ei)) '-' num2str(AChVals(ai)) expSig];
%             end
            name = [Basename 'SpikeTime' num2str(areaCode(i)) '.txt'];
            if exist([OutPath name], 'file')
                disp(name);
                SpikeTimes = importdata([OutPath name]);
                if (~isempty(SpikeTimes))
                nID = unique( SpikeTimes(:,1) ); nID( nID == 62 ) = [];

%% Spike times loaded for this simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Preferred frequency
ev = zeros(1, tstop);
rSPT = round(SpikeTimes(:,2));
    for ST = 1:length(rSPT)
       ev(rSPT(ST)) = ev(rSPT(ST)) + 1; 
    end
    
windowLen = 1024;
[f,Pxxn,tvect,Cxx] = psautospk(ev, 1, windowLen, bartlett(windowLen), windowLen/2, 'none') ;
pxxs(:,end+1) = Pxxn;
% w =max(Pxxn)/Pxxn(1);
% coh(ai, ii) = mean(Pxxn(4:12))/mean(Pxxn);

FireRateS(ii, si, ei, ai).v = length(SpikeTimes)/( cellNumbers(i) * (tstop/1000) );
FireRate(ii, si, ei, ai) = length(SpikeTimes)/(cellNumbers(i)*(tstop/1000) );

                else
%                     PrefFreq(ii, si, ei, ai) = nan;
%                     RelatTheta(ii, si, ei, ai) = nan;
                    FireRateS(ii, si, ei, ai).v = 0;
                    FireRate(ii, si, ei, ai) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                    
                end
            end
            if (length(Pxxn) > 2)        
                    RelatThetaSTD(ii, ei, AChVals+1, si) = sum(Pxxn(4:12))/sum(Pxxn(1:50) );
            else; RelativeThetaSTD(ii, ei, AChVals+1, si) = nan;
            end %Using Ai gets you NO WHERE it is always reset to one value
        end
if (length(pxxs) > 2)        
meanPx = mean( pxxs, 2) ;        
[peakValue, PrefFreq(ii, ei, ai)] = max(meanPx(4:12));
RelatTheta(ii, ei, ai) = sum(meanPx(4:12))/sum(meanPx(1:50) );

allPx = [allPx ; meanPx'];

else
    
                    PrefFreq(ii, ei, ai) = nan;
                    RelatTheta(ii, ei, ai) = nan;
end
        end   %AChVals
    end
% end  % inputs

%%
% figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [25 2 12 4]); % one column 8.3 1.5 column 12.35 cm two columns 17.35 cm 


%%
figure('Color', [1 1 1], 'Units', 'centimeters',...
   'Position', [2.5 0 16.5 12.3]); % one column 8.3 1.5 column 12.35 cm two columns 17.35 cm 
% set(gcf, 'NumberTitle', 'off', ...
%     'Name', sprintf('current: %s', Grand/100));
%  Normalizing pxxx
% normPx = allPx ./ mean(allPx, 2);
% allPx(3, :) = 3 * allPx(3,:);
% frscale = fr ./ fr(1);
%

% normPx = allPx;
% normPx = normr(allPx);
subplot(2,2, 2)
    plot(f, allPx')
    xlim([0 50])
    xlabel('Freq (Hz)')
    ylabel('Power')

    hlegend = legend('full', '-OLM', '-SFA', '-Both', '+-RC', '+-BC');
    set(hlegend, 'box', 'off')

    title(num2str(Grand))
    box off
    
for t = 1:size(allPx, 1)  %Normalize the mean spectrums individually
    normPx(t, 1:50) = allPx(t, 1:50) ./ sum(allPx(t,1:50)); %allPx(t,1); %./ frscale(t); %
%     normPx(t, :) = allPx(t, :) ./ sum(allPx(t,:));
end
% normPx = allPx;
% normPx = normr(allPx);
box off


annotateFunc( 4 ,[0.2 0.560 0.22 0.32] );
% subplot(2,2, 2)
%     plot(f(1:50), normPx')
%     xlim([0 50])
%     xlabel('Freq (Hz)')
%     ylabel('normalized Power')
%     box off
%     hlegend= legend('full', '-OLM', '-SFA', '-Both', '+-RC', '+-BC');
%     set(hlegend, 'box', 'off')
% 
subplot(2,2,3)

    for t = 1:size(allPx, 1)
    %     normPx(t, :) = allPx(t, :) ./ allPx(t,1); %./ frscale(t); %sum(allPx(t,:));
        normPxR(t) = sum(allPx(t, 4:12)) / sum(allPx(t,1:250));
    end
%     plot(normPxR./normPxR(1), 'o')
ResultsSTD = [ResultsSTD; std(RelatThetaSTD(1,1:4, 1, :),0, 4)];
results = [results; normPxR./normPxR(1)]; %Scale by Full model
bar(normPxR./normPxR(1), 'facecolor', [0.5 0.5 0.5])
hold on
% errorbar(normPxR./normPxR(1), std(RelatThetaSTD(1,1:4, 1, :),0, 4), '.', 'color', [0.2 0.2 0.2], 'linewidth', 1.5);

set(gca, 'xtick', [1:4])
set(gca, 'xticklabel', ['Full '; '-OLM '; '-SFA '; '-Both'])

ylabel('Relative 4-12Hz power')
xlim([0 5])
% rotateXLabels(gca, 45)
box off
chil = get(gca, 'children');
% set (chil(1), ...
%     'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
hold on; plot([0:7], [1 1 1 1 1 1 1 1], ':k')
    %%
subplot(2,2,4)
    size(FireRate)
    mfr = mean(FireRate, 2);
    for g = 1:size(mfr, 3)
       fr(g) = mfr(1,1,g); 
    end

    plot(fr, '*k')
ylabel('Firing rate')
set(gca, 'xticklabel', ['Full'; '-OLM'; '-SFA'; '-Bth'; '+-RC'; '+-BC'])
box off
% ylim([0 10])

    
end %Grand
%%
beep off
ali ali

%%
results
ACh1 = [ 1.0000    0.8497    0.5906    0.9974    0.4704    1.0697];
% ACh0 = [ 1.0000    0.9777    0.5568    0.9411    0.3700    1.0537];
% ACh2 = [ 1.0000    0.7749    0.7507    1.1714    1.0189    1.3728];
close all
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [15 12 18 4.5]); % one column 8.3 1.5 column 12.35 cm two columns 17.35 cm 
hsubplots= []; htitles= [];
for Grand = [1 0 2]
hsubplots(Grand+1) = subplot(1,3, Grand+1);
bar(results(Grand+1,:), 'facecolor', [0.5 0.5 0.5])
hold on
errorbar(results(Grand+1,:), ResultsSTD(Grand+1,:), '.', 'color', [0.2 0.2 0.2], 'linewidth', 1.5);

set(gca, 'xtick', [1:4]); ylabel('Relative theta');
htitles(Grand+1) = title(['ACh '  num2str(Grand)]);
curPos = get(gca,'position');
curPos(2) = 0.2; curPos(4) = 0.7;
set(gca, 'position', curPos)
set(gca, 'xticklabel', ['Full '; '-OLM '; '-SFA '; '-Both'])
xlim([0 5]); ylim([0 2]);

rotateXLabels(gca, 45)
box off
chil = get(gca, 'children');
% set (chil(1), ...d
%     'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
hold on; plot([0:7], [1 1 1 1 1 1 1 1], ':k')

% errorbar(results{Grand+1}, resultsSTD(Grand+1, :) , '.', 'color', [0.2 0.2 0.2], 'linewidth', 1);
end

set(htitles, 'position', [0.5 0.87 0])

%%
subplot(2,2, 1)
pf = mean ( FireRate, 2);
% pf = mean ( RelatTheta, 2);
% pf = mean ( PrefFreq, 2);
a1 = pf(:,:,:,3);
co= {'r', 'b', 'g',  'k', 'r--', 'bo'}
for y = 1:size(a1, 3)
    plot(a1(:,1, y), co{y} )
    hold on
end

subplot(2,2 , 2)
a1 = PrefFreq(:,:,3);
co= {'r', 'b', 'g',  'k', 'r--', 'bo'};
for y = 1:size(a1, 2)
    plot(a1(:, y), co{y} )
    hold on
end

subplot(2,2 , 3)
a1 = RelatTheta(:,:,3);
co= {'r', 'b', 'g',  'k', 'r--', 'bo'}
for y = 1:size(a1, 2)
    plot(a1(:, y), co{y} )
    hold on
end
