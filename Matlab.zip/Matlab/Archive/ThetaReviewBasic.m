%     close all; clear all; clc;
 
%% Trying to visualize multiple seeds
 
xplots = 4; yplots =4; plotSize= 4;
% 4: RC   5: Resonance, Full
% figure('Color', [1 1 1], 'Units', 'centimeters', ...
%     'Position', [20.5 4 12.35  10])
if  plotSize == 1
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [18 8.9 8.5  15])
end; if plotSize == 2
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [18 4 8.5  8.5])
end; if plotSize == 3   
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [18 4 17.4  10])
end; if plotSize == 4   
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [3 4 11.6  4])
end
if plotSize == 5       % Full model new figure// tstop > 3000 switches to resonance
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [3 4 17.6  7])
end
% one column 8.3 1.5 column 12.35 jneuro 11.6cm two columns 17.35 cm 
 % 1.5col with nocrop 1460 pixel with crop 1278 so in cm 14.1188 corrected
 % to 14.1488 cm
    
 cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];
ibc=4;iolm=3;iec=1; idg = 5;
OutPath= '..\..\Outputs3\Quant\';
tstop = 3000; 
% expSig = '15-*-1-1Final';schematic = 2;; ysch = 0.6;
% expSig = '50-*-2-1Fi = 3;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.55;
% expSig = '50-*-3-1Final';schematic = 4;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;
% expSig = '50-*-4-1Final';schematic = 5;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.55;
% expSig = '50-*-6-1Final';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;
% expSig = '250-*-10-1Final'; schematic = 17;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 3000; 
% expSig = '50-*-12-1Final';schematic = 7; ibc=2;iolm=2;iec=1; ysch = 0.53;
% expSig = '150-1-16-100Final';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;
% 
% expSig = '50-*-5-1Final';schematic = 16;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 30000; 

% Experiments with the name  50-*-5-0.01Final with a values 0.001 0.003 0.005
% 0.01 0.05 0.1

% expSig = '50-*-5--70Final';schematic = 16;ibc=2;iolm=2;iec=2; ysch = 0.6;tstop = 30000; 
% Experiments with the name  50-*-5--75Final with Vr values -80:5:-60
% expSig = '50-*-17-1Final';schematic = 3;ibc=2;iolm=2;iec=2; ysch = 0.55;
% expSig = '15-*-1-1Final';schematic = 2; ibc=4;iolm=3;iec=1;idg=2; ysch = 0.6; tstop = 3000;
% expSig = '50-*-3-8Final'; schematic = 2;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 3000; 

% OutPath= '..\..\Outputs3\Quant\LastPush\';
% expSig = '50-*-10-0FinalPush_noU';schematic = 3;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;
% expSig = '50-*-6-0FinalPush_noU';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;
tstop = 5000;
% expSig = '50-*-6-1ECNoSpatial';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;
% THIS IS THE ONE FOR EC 
expSig = '50-*-6-1ECFinal';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;

% expSig = '15-*-3-1DGFinal';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;

% THE 5000ms experiments
OutPath= '../../Outputs/Review/';
tstop = 5000;
% expSig = '50-*-1-1FinalPush';schematic = 2; ysch = 0.6;ibc=4;iolm=3;iec=1; idg = 5;
% expSig = '50-*-4-2Review';schematic = 5;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.55;
expSig = '10-*-37-0Review';schematic = 7; ibc=2;iolm=2;iec=1;idg=2; ysch = 0.53;
expSig = '11-*-13-0Review';schematic = 7; ibc=2;iolm=2;iec=2;idg=2; ysch = 0.53;
% expSig = '4-*-15-1AChReview'; schematic = 2;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;
expSig = '4-*-15-1AChReview';schematic = 7; ibc=2;iolm=2;iec=2;idg=2; ysch = 0.53;

% expSig = '10-*-35-1hReview';schematic = 7; ibc=2;iolm=2;iec=2;idg=2; ysch = 0.53;


% expSig = '50-*-5-1FinalPush';schematic = 16;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 30000; 

% with h_current
% expSig = '50-*-5-1LastPushh';schematic = 16;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 30000; 
% with h but no u (a = 0.5)
% expSig_h = '50-*-5-0.5LastPush_h_noU';schematic = 18;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 30000; 
% [0.001, 0.01, 0.05, 0.10, 0.30, 0.50, 0.80]
% NO h  no u ( a = 0.5)
% inputRate = 20;  % tstop = 5000;
% expSig = [num2str(inputRate) '-*-5-0FinalPush_hh'];schematic = 18;ibc=2;iolm=2;iec=2;idg=2; ysch = 0.6;tstop = 30000; 


hsubplots = []; 
 
schem=      1;
FFTavg =        2;
autoCorr=       3;
ecFFT=      6;
spatialCoh=     5;
spikePlot=      7;
firingR=        8;
volt1=      9;
volt2=      10;
olmFFT=     4; uavg1 = 12; isi1 = 13; FFTavg2 = 14; uavg2 = 15; isi2 = 16;
bcFFT=      5;
dgFFT=      11; 
 
% CA3
i = 2;
fileNames = dir([OutPath expSig 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
 
windowLen = 1024;
 
hsubplots(schem) = subplot (yplots,xplots,schem);
 
 cxxs = [];
pxxs = []; spikes = []; intervals = struct();
% SpikeTimes = SpikeTimes( SpikeTimes(:, 1) == 1, :);
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);
    disp(sname)
 % restricting analysis to certain locations
% locs = load(([OutPath '152EC6s' 'Loc0' num2str(areaCode(i)) '.txt']));
% n= [locs (0:62)'];
%  ns= n(n(:,1)<4,4);
%  
% no = [locs(:,1) (0:62)'];
% [no, in] = sortrows(no)
% so=no(:,2);
% sorted = [so(SpikeTimes(:, 1)+1) SpikeTimes(:, 2)]
% SpikeTimes = SpikeTimes ( ismember(SpikeTimes(:,1), ns) ,:);

    ev = zeros(1, tstop);
    rSPT = round(SpikeTimes(:,2));
    for ST = 1:length(rSPT)
       ev(rSPT(ST)) = ev(rSPT(ST)) + 1; 
    end
 
        nID = unique(SpikeTimes(:,1));
    spikes(end+1) = length(SpikeTimes(:,2));
    [f,Pxxn,tvect,Cxx] = psautospk(ev, 1, windowLen, bartlett(windowLen), windowLen/2, 'none') ;
 
    pxxs(:,end+1) = Pxxn;
    cxxs(:, end+1)= Cxx;
 
    
nID = unique( SpikeTimes(:,1) ); nID( nID == 62 ) = [];

TimeWindow = 400;
%% ISI    
for kk = 1:length(nID)
    Spikes = SpikeTimes( SpikeTimes(:,1)== nID(kk) ,2);
    if (~isempty(Spikes))
        for sp = 1:length(Spikes)
            if (Spikes(sp) < tstop-TimeWindow) % Discard the last TimeWIndow spikes
                diff = Spikes-Spikes(sp);
                ISIs = diff( diff>0 & diff<TimeWindow);
                if (~isempty(ISIs))
                %%% Keeep only the NEXT spike
                minISIs = min(ISIs);
    %             minISIs = (ISIs);
                            intervals(end+1).nn = minISIs;
%                 else
%                     dist(end+1).nn = 0;
                end
            end
        end
    end % if spike empty
end

end
 

%%
% close all
% figure('Color', [1 1 1])
% 
% for k = 1:9
%     subplot(3,3, k)     
%     plot(pxxs(:,k)); xlim([0 50])
% end
%%
% close all
% expSig = '15*Full'; %  
% fileNames = dir([OutPath expSig 'Volts' '.txt']);
% volts = importdata([OutPath fileNames(1).name]);
% figure('Color', [1 1 1], 'Units', 'centimeters', ...
%     'Position', [5 4 32.35  15])
% 
% for k = 5:5:30
%     subplot(30/5, 1,k/5)
%  plot( volts(:, 1), volts(:, k))
%  xlim([0 3000]);
% end
%%
% plot(mean(pxxs,2));
xx = 0:size(pxxs,1)-1;
yy = mean(pxxs,2);
sy = std(pxxs');
 
hsubplots(FFTavg) = subplot (yplots,xplots, FFTavg); % second subplot

rr = 1000;
boundedline(xx', yy/rr, sy/rr, 'k')
[c4, i4] = max(yy);
if length(i4) >= 1; disp(['Peak is at: ' num2str(xx(i4)) 'Hz']); 
xlim([0 50])
    xl = xlim; yl = ylim;
% annotation('arrow', [ xx(i4)/(xl(2))*1.1 c4*1.1/yl(2)/rr ],...
%     [(xx(i4))/xl(2) c4/yl(2)/rr], 'Color', [0.7 0.7 0.7],...
%     'HeadStyle', 'vback3','HeadSize', 5,...
%     'LineWidth', 1, 'LineStyle', '-');

%     line([ xx(i4)*1.3 (xx(i4))],    [c4*1.3/rr  c4/rr], 'LineWidth', 1, 'Color', [0.7 0.7 0.7])
    
end;


hsubplots(autoCorr) =  subplot (yplots,xplots, autoCorr);
%   plot(tvect,Cxx);
%  Theta = MyFindPeak(tvect, Cxx);
%  
% xx = tvect ;%0:size(cxxs,1)-1;
% yy = mean(cxxs,2);
% sy = std(cxxs');
%  boundedline(xx', yy, sy, 'k')
% Gettting the firing rate plot
  binSize = 20; %%ms
spiketimes = SpikeTimes(:, 2); 
timeMax = max(spiketimes);
timeMax = timeMax - binSize;
binSpikeCount = [];
 
for tt=0:1:tstop %timeMax
   binSpikeTimes = spiketimes((spiketimes(:) > tt-(binSize/2) & spiketimes(:) < tt+ (binSize/2) ) );
   binSpikeCount(end+1) = length(binSpikeTimes);
end
firingRate= (1000*  binSpikeCount / binSize); % / length(nID) ; 
 
% plotting spike raster plots
hsubplots(spikePlot) = subplot (yplots,xplots, spikePlot); 
% plot(sorted(:,2),sorted(:,1), '.')
  plot(SpikeTimes(:,2),SpikeTimes(:,1), '.')
 xlim([0 3000])

 
hsubplots(firingR) = subplot (yplots,xplots, firingR);
plot(firingRate/1000)% plot(firingRate)
 
 %%
     hsubplots(volt1)=subplot(yplots, xplots, volt1);
     hsubplots(volt2)=subplot(yplots, xplots, volt2);
fileNames = dir([OutPath expSig 'Volts' '.txt']);
try
volts = importdata([OutPath fileNames(1).name]);



plot(hsubplots(volt1),volts(:, 1), volts(:, 3),'r')
% axis off;
box off;
xlim([0 3000]);
 ylim([-100 40]);
set(gca, 'YTick'       , [-80 -20 40], 'XTick', 0:500:3000);
    
set(gca, 'XTickMode','manual')
% set(gca, 'XTickLabel',num2str(get(gca,'XTick')')) 
% set(gca, 'XTickLabel',[]) 
 

plot(hsubplots(volt2),volts(:, 1), volts(:, 2))

 catch exception
end


% Olm 
hsubplots(olmFFT) = subplot (yplots,xplots,olmFFT);
DrawSpectrum(iolm, OutPath, expSig, tstop, windowLen, hsubplots(olmFFT))
  
% BC
hsubplots(bcFFT) = subplot (yplots,xplots,bcFFT);
DrawSpectrum(ibc, OutPath, expSig, tstop, windowLen, hsubplots(bcFFT)) 
 
% EC
hsubplots(ecFFT) = subplot (yplots,xplots,ecFFT);
DrawSpectrum(iec, OutPath, expSig, tstop, windowLen, hsubplots(ecFFT))

% DG
hsubplots(dgFFT) = subplot (yplots,xplots,dgFFT);
DrawSpectrum(idg, OutPath, expSig, tstop, windowLen, hsubplots(dgFFT))

%   [mean(spikes) std(spikes)]/(63*3)

  
  
hsubplots(isi1) = subplot (yplots,xplots,isi1);
hsubplots(uavg1) = subplot (yplots,xplots,uavg1);
hsubplots(FFTavg2) = subplot (yplots,xplots, FFTavg2); % second subplot
hsubplots(isi2) = subplot (yplots,xplots,isi2);
hsubplots(uavg2) = subplot (yplots,xplots,uavg2);

%%  Spiking oscillations Resonance 
if (schematic == 16)
expSig = 'Final';exper = 5; preArea = 2 - 1 ;input = 50;  ACHvals = [1]; seeds = 0:9;
% [udata, isi] = DrawSpikeTriggered(i, preArea, OutPath, expSig, input, seeds, exper, ACHvals, tstop, tstop/3, hsubplots(olmFFT), hsubplots(bcFFT)) ;

% dlmwrite('isi.txt', isi)
isi = importdata('isi.txt');
% dlmwrite('isi.txt', isi(1:5000))
% dlmwrite('udata.txt', udata)
udata = importdata('udata.txt');

axes(hsubplots(uavg1))
plot(udata)

axes(hsubplots(isi1))
[counts, binValues] = hist(isi(1:4000), 100); 
NormalizedCounts = 100*counts/ sum(counts);
bar(binValues, NormalizedCounts, 'barwidth', 1)

% OutPath='..\..\Outputs3\Quant\';
% expSig = 'Final';exper = 5; preArea = 2 - 1 ;input = 45;  ACHvals = [0.05]; seeds = 0:1;
% [udata2, isidata2] = DrawSpikeTriggered(i, preArea, OutPath, expSig, input, seeds, exper, ACHvals, tstop, tstop/3, hsubplots(uavg2), hsubplots(isi2)) ;
% dlmwrite('isi2.txt', isidata2)
isidata2 = importdata('isi2.txt');
% dlmwrite('isi2.txt', isidata2(1:5000))
% dlmwrite('udata2.txt', udata2)
udata2 = importdata('udata2.txt');

axes(hsubplots(isi2))
[counts2, binValues2] = hist(isidata2(1:4000), 100); 
NormalizedCounts2 = 100*counts2/ sum(counts2);
bar(binValues2, NormalizedCounts2, 'barwidth', 1)

axes(hsubplots(uavg2))
plot(udata2)

hsubplots(FFTavg2) = subplot (yplots,xplots,FFTavg2);
DrawSpectrum(2, OutPath, '50-*-5-0.05Final', tstop, windowLen, hsubplots(FFTavg2))

end % if

%%  h-current Spiking oscillations Resonance 
if (schematic == 18)

expSig = 'FinalPush_hh';
exper = 5; preArea = 2 - 1 ;input = 50;  ACHvals = [0]; seeds = 0:9;
exper = 5; preArea = 2 - 1 ;input = inputRate;  ACHvals = [0]; seeds = 1:5;

[udata, isi] = DrawSpikeTriggered(i, preArea, OutPath, expSig, input, seeds, exper, ACHvals, tstop, tstop/3, hsubplots(olmFFT), hsubplots(bcFFT)) ;

% dlmwrite('isi.txt', isi)
% isi = importdata('isi.txt');
% dlmwrite('isi.txt', isi(1:5000))
% dlmwrite('udata.txt', udata)
% udata = importdata('udata.txt');

axes(hsubplots(uavg1))
plot(udata)

axes(hsubplots(isi1))
[counts, binValues] = hist(isi(1:4000), 100); 
NormalizedCounts = 100*counts/ sum(counts);
bar(binValues, NormalizedCounts, 'barwidth', 1); box off

    axes(hsubplots(isi1))
    chil = get(gca, 'children');
    set (chil(1), ...
        'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
    xlim([-10 300]); set(gca, 'XTick'       , 0:100:300 );
    ylim([0 6])
    box off

% OutPath='..\..\Outputs3\Quant\';
expSig_h = 'FinalPush_hh'; ACHvals = [1];
[udata2, isidata2] = DrawSpikeTriggered(i, preArea, OutPath, expSig_h, input, seeds, exper, ACHvals, tstop, tstop/3, hsubplots(uavg2), hsubplots(isi2)) ;
% dlmwrite('isi2.txt', isidata2)
% isidata2 = importdata('isi2.txt');
% dlmwrite('isi2.txt', isidata2(1:5000))
% dlmwrite('udata2.txt', udata2)
% udata2 = importdata('udata2.txt');

axes(hsubplots(isi2))
[counts2, binValues2] = hist(isidata2(1:4000), 100); 
NormalizedCounts2 = 100*counts2/ sum(counts2);
hold off; bar(binValues2, NormalizedCounts2, 'barwidth', 1); 


    axes(hsubplots(isi2))
    chil = get(gca, 'children');
    set (chil(1), ...
        'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
    xlim([-10 300]); set(gca, 'XTick'       , 0:100:300 );
    ylim([0 6])
    box off

axes(hsubplots(uavg2))
plot(udata2)

hsubplots(FFTavg2) = subplot (yplots,xplots,FFTavg2);
DrawSpectrum(2, OutPath, [num2str(inputRate) '-*-5-1FinalPush_hh'], tstop, windowLen, hsubplots(FFTavg2))
   axes(hsubplots(FFTavg2))
%    ylim([0 1.5])
   xlim([0  50]);
   set(gca, 'XTick'       , 0:10:50);
   

end % if


%%



if (schematic == 55555) % TURNED OFF % THe RC case. Exp 4

%% Adding the RC strength effect
set(gcf, 'Position', get(gcf, 'Position') + [0 0 4 0])
% set(hsubplots, 'units', 'centimeters')

% [coh, mc] = DrawThetaMesh(OutPath, 'Final', input, ACHvals, seeds, exper, tstop);
% spike count
%     mc = mean(mc, 3)/(63*3);
axes(hsubplots(autoCorr))
load('./Temp Data/cohRCstd', 'coh');
scoh =  std(coh, '', 3);
mcoh =  mean(coh, 3);
    
weights = [0.1:0.05:1];
boundedline(weights, mcoh(1,:), scoh(1,:), 'r', 'alpha')
boundedline(weights, mcoh(2,:), scoh(2,:), 'k', 'alpha')
% Formatting
co =[0.2 0.2 0.2];    
chil = get(hsubplots(autoCorr), 'children');
set (chil(3), ...
    'Color'         , [.8 .2 .2] , ...
    'LineWidth'     , 1             );
set (chil(1), ...
    'Color'         , co , ...
    'LineWidth'     , 1  , ...             
    'LineStyle'     , '--'       );

%%
axes(hsubplots(autoCorr));
%     set(gca, 'YTick'       , 0:20:63);
        xlim([0.1  0.6]); ylim([3 10]);
%         xlabel('Recurrent connection weight')
%         ylabel('Network Freq.(Hz)')
texters (1) = text( 0.491, 0.96, {'Control'}, 'Units', 'Normalized')        ;
texters (2) = text( 00.1822  ,  0.1926 , {'No', 'depression'}, 'Units', 'Normalized');

end

%% FR distribution
if (schematic ==18)

expSig = 'FinalPush_noU';
exper = 5; preArea = 2 - 1 ;ACHvals = [0]; seeds = 1:6;

input = inputRate;  

ACHvals = [0];
% expSigFR = [num2str(input) '-*-' num2str(exper) '-' num2str(ACHvals) expSig];
FRdistribution( i, OutPath, expSig, input, seeds, exper, ACHvals,  tstop, windowLen, hsubplots(uavg1) )
axes(hsubplots(uavg1))
box off 

expSig = 'FinalPush_noU';
exper = 5; preArea = 2 - 1 ; seeds = 1:6;

ACHvals = [1];
% expSigFR = [num2str(input) '-*-' num2str(exper) '-' num2str(ACHvals) expSig];
FRdistribution( i, OutPath, expSig, input, seeds, exper, ACHvals,  tstop, windowLen, hsubplots(uavg2) )

end %firing rate dist

%% distance vs coherence between pairs of neurons
if (schematic == 7)
    i = 2;
twindow = 5;
set(gcf, 'Position', get(gcf, 'Position') + [0 0 4 0])

axes(hsubplots(autoCorr));
%         xlabel('Recurrent connection weight')
%         ylabel('Network Freq.(Hz)')
texters (1) = text( 0.491, 0.96, {'No spatial', 'organization'}, 'Units', 'Normalized')        ;
texters (2) = text( 00.1822  ,  0.1926 , {'Spatially', 'organized'}, 'Units', 'Normalized');

%     Loc = importdata([OutPath 'Loc0' num2str(areaCode(i)) '.txt']);
   Loc = importdata(['..\..\Outputs3\Quant\LastPush\' '/50-0-6-1ECFinalLoc0' num2str(areaCode(i)) '.txt']);

fileNames = dir(['..\..\Outputs3\Quant\LastPush\' expSig 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
distances = []; mean_cohs = [];
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);

    dist = @(from, to) [abs(Loc(from+1,1) - Loc(to+1,1))];
    dist(0,6)

    distCoh = [];
    for ii = 0:cellNumbers(i)-2
        for jj = ii +1:cellNumbers(i)-2
            distCoh(end+1, 1) = dist(ii,jj);
            distCoh(end, 2) = CoherenceXY(ii,jj, twindow, tstop, SpikeTimes);
        end
    end
    distCoh(:,1) = round(distCoh(:,1) * 100)/100;
    uniDist = unique(distCoh(:,1));

    dmc = [];
    for dd = 1:length(uniDist)
        specDistCoh = distCoh ( distCoh(:,1) == uniDist(dd), :);
        meanC = mean(specDistCoh(:,2));
        stdC = std(specDistCoh(:,2));
        dmc(end+1, :) = [uniDist(dd), meanC, stdC];
    end
    distances = [distances dmc(:,1)];
    mean_cohs = [mean_cohs dmc(:,2)];
end

% THE NO SPATIAL EC CASE
fileNames = dir([OutPath '50-*-6-1ECNoSpatial' 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
distancesNoSpatial = []; mean_cohsNoSpatial = [];
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);

    dist = @(from, to) [abs(Loc(from+1,1) - Loc(to+1,1))];
    dist(0,6)

    distCoh = [];
    for ii = 0:cellNumbers(i)-2
        for jj = ii +1:cellNumbers(i)-2
            distCoh(end+1, 1) = dist(ii,jj);
            distCoh(end, 2) = CoherenceXY(ii,jj, twindow, tstop, SpikeTimes);
        end
    end
    distCoh(:,1) = round(distCoh(:,1) * 100)/100;
    uniDist = unique(distCoh(:,1));

    dmc = [];
    for dd = 1:length(uniDist)
        specDistCoh = distCoh ( distCoh(:,1) == uniDist(dd), :);
        meanC = mean(specDistCoh(:,2));
        stdC = std(specDistCoh(:,2));
        dmc(end+1, :) = [uniDist(dd), meanC, stdC];
    end
    distancesNoSpatial = [distancesNoSpatial dmc(:,1)];
    mean_cohsNoSpatial = [mean_cohsNoSpatial dmc(:,2)];
end


boundedline(mean(distancesNoSpatial, 2), mean(mean_cohsNoSpatial, 2), std(mean_cohsNoSpatial,0, 2), 'r', 'alpha') %boundedline(dmc(:,1), dmc(:,2), dmc(:,3), 'k', 'alpha')

boundedline(mean(distances, 2), mean(mean_cohs, 2), std(mean_cohs,0, 2), 'k', 'alpha') %boundedline(dmc(:,1), dmc(:,2), dmc(:,3), 'k', 'alpha')

% Formatting
co =[0.2 0.2 0.2];
chil = get(hsubplots(autoCorr), 'children');
if (length(chil) > 2 ); 
    set (chil(3), ...
    'Color'         , [.8 .2 .2] , ...
    'LineWidth'     , 1             ); end
set (chil(1), ...
    'Color'         , co , ...
    'LineWidth'     , 1  , ...             
    'LineStyle'     , '--'       );



% Spatial profiling
% get the number of connections to each pyr
% number of connections for EC
% Ratio of shared vs non-shared between each pyr pair.
fileNames = dir(['..\..\Outputs3\Quant\LastPush\' '50-0-6-1ECFinal' 'Connections' '.txt']);
try
con = importdata(['..\..\Outputs3\Quant\LastPush\' fileNames(1).name]);
%ConID,, preArea, preId, postArea, postId, SynapseType

%
filter =  con( (con(:,2) == 0 & con(:,4) == 1), :);

received = [];
for post = 0:62
    received(post+1) = sum(filter(:,5) == post);
end 
% average number of EC inputs received by each pyr cell ~ 5
mean(received)
% From this you really can calculate everything else!
% 
sent = [];
for pre = 0:30
    sent(pre+1) = sum(filter(:,3) == pre);
end 

% Determined amount shared to each ca3 ca3 pairs
% [CA3 ID, {projecting EC IDs}]
%   pUTTING ALL THE EC NEURONS THAT PROJECT TO EACH CA3 NEURON IN A CELL
%   ROW
for j = 1:62;
lol{j} = [ filter( filter(:,5) == j , 3) ];
end

shares = [];
for j1 = 1:62;
    for j2 = 1:62;
%         shares(end+1) = sum(ismember( lol{j1}, lol{j2} ) ) ;
        shares(end+1) = sum(ismember( lol{j1}, lol{j2} ) ) / length(lol{j1}) ;

    end
end

figure
hist(shares)
disp('mean(shares)')
mean(shares)
% 
% postArea = 1; target = 1
% for n = 1:size(con, 1)
%        if ((con(n,4) == postArea) && (con(n,5) == target))        
%            pre(end+1, :)= con(n,:);
%        end
% end
% uni = unique(pre(:, 2));
% 
% uni

end
hold off
hist([intervals.nn], 100)
end

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%% Formatting %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
co =[0.2 0.2 0.2];
% Labeling subplots
if  plotSize == 1 
subLabels = {'A', 'B', 'N', 'C1', 'C2','C3','D', 'E','F', 'G', 'H', 'I'};end; if plotSize == 2
subLabels = {'A', 'B', 'N', 'C', 'D', 'C','C', 'D', 'H', 'I'};end; if plotSize == 3   
subLabels = {'A', 'B', 'N', 'C', 'D', 'E','F', 'G', 'H', 'I'};end
if plotSize == 4
subLabels = {'A', 'C', 'D', 'B1', ' 2', 'B','B1', ' 2', 'H', 'I'};end;
if plotSize == 5
    subLabels = {'A', 'C', 'N', 'D1', '  2','  3','B1', '2','3', '4', '  4', 'I', 'L', 'M', 'N', 'O', 'P'};
    if schematic == 16;
    subLabels = {'A', 'C1', 'N', 'D1', '  2','  3','B1', '  2','  3', '  4', '  4', '  2', '  3', 'D1', '  2', '  3', 'P', 'Q', 'R', 'S', 'T'};end;
end; %uavg1 = 12; isi1 = 13; FFTavg2 = 14; uavg2 = 15; isi2 = 16;
    if schematic == 18;
    subLabels = {'A', 'A1', 'N', 'D1', '  2','  3','B1', '  2','  3', '  4', '  4', '  2', '  3', 'B1', '  2', '  3', 'P', 'Q', 'R', 'S', 'T'};end;


if schematic==4
subLabels = {'E', 'F', 'N', 'C', 'D', 'C','G', 'H', 'H', 'I'};end
subLabels = subLabels';
%                   Title                   x           y
subTexts ={'None'          'None'          'None'          ;
           'None'          'Frequency (Hz)'    '[(spk/sec)^2/Hz]';
           'None'          'Dist (mm)'  'Coherence';
%            'None'          'Recurrent connection weight'  'Network Freq.(Hz)';
           'None'          'None'         '[(spk/sec)^2/Hz]';
           'None'          'None'    'None';
           'None'          'Frequency (Hz)'    '[(spk/sec)^2/Hz]';
           'None'          'Time (ms)'         'Neuron';
           'None'          'None'         'Pop. (spk/sec)';
           'None'          'None'                '(mV)';
           'None'          'Time (ms)'         '(mV)';
           'None'          'Frequency (Hz)'    'None';
%            'None'         'Rate (Hz)'    'count';
           'None'          'Time after spike(ms)'    'u(uA)';
           'None'          'ISI (ms)'       '%';
           'None'          'Frequency (Hz)'    'None';
%            'None'          'Rate (Hz)'    'count';
                      'None'          'Time after spike(ms)'    'None';
           'None'          'ISI (ms)'       'None';
           };
 
        
% Panel locs
if  plotSize == 1
set(hsubplots(schem), 'Position', [0.185 0.788448 0.3504 0.1607])
set(hsubplots(FFTavg), 'Position', [ 0.6051    0.7884    0.3504    0.1609])
set(hsubplots(autoCorr),'Position',[1.760509554140127 0.852674 0.2 0.106])
set(hsubplots(ecFFT), 'Position', [0.7251    0.569    0.229    0.1194])
 
set(hsubplots(olmFFT), 'Position', [0.185    0.569    0.229    0.1193])
set(hsubplots(bcFFT), 'Position', [0.46    0.569    0.219    0.1193])

h = 0.02; margin = 0.185; wide = 0.77; % end is 0.955
 
set(hsubplots(spikePlot), 'Position',[0.184713375796178 0.370617283950617 0.772285350318471 0.1111]);
% [margin    h+0.35    0.77    0.1111])
set(hsubplots(firingR), 'Position', [  margin    h+0.26    wide 0.07])
 set(hsubplots(volt1), 'Position', [  margin    h+0.138    wide 0.073])
set(hsubplots(volt2), 'Position', [  margin    h+0.05    wide 0.073])

 end; if plotSize == 2
     subTexts{8,2} = 'Time (ms)';
set(hsubplots(schem), 'Position', [0.185 0.788448 0.3504 0.1607])
set(hsubplots(FFTavg), 'Position', [ 0.571    0.6231    0.3504    0.29515])
%6051
set(hsubplots(autoCorr),'Position',[1.7667    0.7592    0.2053    0.15986])

set(hsubplots(ecFFT), 'Position', [1.6051    0.559    0.3504    0.1194])
set(hsubplots(spatialCoh), 'Position', [1.185    0.559    0.229    0.1193])
 set(hsubplots(olmFFT), 'Position', [1.6051    0.559    0.3504    0.1194])
set(hsubplots(spatialCoh), 'Position', [1.185    0.559    0.229    0.1193])
 
h = 0.02; margin = 1.185; wide = 0.77; % end is 0.955
 
set(hsubplots(spikePlot), 'Position',[0.184713375796178 0.3022 0.77221 0.181]);
% [margin    h+0.35    0.77    0.1111])
set(hsubplots(firingR), 'Position', [  0.185     0.1464    wide 0.1257])
 set(hsubplots(volt1), 'Position', [  margin    h+0.138    wide 0.073])
set(hsubplots(volt2), 'Position', [  margin    h+0.05    wide 0.073])
 end; if plotSize == 3   
set(hsubplots(schem), 'Position', [0.185 0.788448 0.3504 0.1607])
set(hsubplots(FFTavg), 'Position', [ 0.6051    0.7884    0.3504    0.1609])
set(hsubplots(autoCorr),'Position',[0.760509554140127 0.852674 0.2 0.106])
set(hsubplots(ecFFT), 'Position', [0.6051    0.559    0.3504    0.1194])
 
set(hsubplots(spatialCoh), 'Position', [0.185    0.559    0.229    0.1193])
 
h = 0.02; margin = 0.185; wide = 0.77; % end is 0.955
 
set(hsubplots(spikePlot), 'Position',[0.184713375796178 0.370617283950617 0.772285350318471 0.1111]);
% [margin    h+0.35    0.77    0.1111])
set(hsubplots(firingR), 'Position', [  margin    h+0.26    wide 0.07])
 set(hsubplots(volt1), 'Position', [  margin    h+0.138    wide 0.073])
set(hsubplots(volt2), 'Position', [  margin    h+0.05    wide 0.073])
 end
%%
if plotSize == 4
     subTexts{8,2} = 'Time (ms)'; subTexts{7,2} = 'None';
h = 0.2; margin = 3 ; wide = 4.7; % end is 0.955

set(hsubplots, 'units', 'centimeters')
set(hsubplots, 'Position', [-11.7    2.6    1.7    1])

set(hsubplots(FFTavg), 'Position', [ 9    1    2.38    2.3])
set(hsubplots(spikePlot), 'Position',[margin h+2.2 wide 1.2]);
set(hsubplots(firingR), 'Position', [  margin    h+.8    wide 0.8])

set(hsubplots(schem), 'Position', [1.285 1 2.38 2.3])

if schematic ==7
set(hsubplots(autoCorr), 'Position', [ 12.5    1    2.38    2.3]); end;

end;
     
 %%
if  plotSize == 5

set(hsubplots(schem), 'Position', [0.085 0.788448 0.3504 0.1607])

set(hsubplots(autoCorr),'Position',[1.760509554140127 0.852674 0.2 0.106])

h = 0.2; margin = 5 ; wide = 5; % end is 0.955

axes(hsubplots(firingR));
set(gca, 'XTickLabel',[]) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(hsubplots, 'units', 'centimeters')
set(hsubplots(FFTavg), 'Position', [ 11.5    4.8    3.8    1.7])
set(hsubplots(olmFFT), 'Position', [11.4    2.6    1.7    1])
set(hsubplots(bcFFT), 'Position', [13.6    2.6    1.7    1])
set(hsubplots(ecFFT), 'Position', [11.4    0.96    1.7    1])
set(hsubplots(dgFFT), 'Position', [13.6    0.96    1.7    1])


set(hsubplots(uavg1), 'Position', [-12.4    3.2    2    1])
set(hsubplots(isi1), 'Position', [-12.4    0.96    2    1])

set(hsubplots(FFTavg2), 'Position', [ -15.4    5.2    2    1.5])
set(hsubplots(uavg2), 'Position', [-15.4    3.2    2    1])
set(hsubplots(isi2), 'Position', [-15.4    0.96    2    1])

if tstop>5000
    marg = 11.7;
set(hsubplots(FFTavg), 'Position', [ marg     5.2    2.3    1.5])
set(hsubplots(uavg1), 'Position', [  marg     3.2    2.3    1])
set(hsubplots(isi1), 'Position', [   marg     0.96    2.3    1])

set(hsubplots(FFTavg2), 'Position', [ marg+3.3    5.2    2.3    1.5])
set(hsubplots(uavg2), 'Position',   [ marg+3.3    3.2    2.3    1])
set(hsubplots(isi2), 'Position', [    marg+3.3    0.96    2.3    1])

set(hsubplots(olmFFT), 'Position', [-12.8    2.6    1.7    1])
set(hsubplots(bcFFT), 'Position', [-14.8    2.6    1.7    1])
set(hsubplots(ecFFT), 'Position', [-12.8    0.96    1.7    1])
set(hsubplots(dgFFT), 'Position', [-14.8    0.96    1.7    1])
end
set(hsubplots(spikePlot), 'Position',[margin 5.3 wide 1.3]);
% [margin    h+0.35    0.77    0.1111])
set(hsubplots(firingR), 'Position', [  margin    h+3.3    wide 1])
 set(hsubplots(volt1), 'Position', [  margin    h+1.92    wide 0.81])
set(hsubplots(volt2), 'Position', [  margin    h+.8    wide 0.81])

 end;
 
 
%% Adding titles and x y labels
% k = 1
for k = 1:length(hsubplots)
axes(hsubplots(k));
    pos = get(gca,'Position');
    xpos = -1.1 / pos(3);
    
        if (k > length(subLabels) || k > size(subTexts, 1))
            break;
        end
 
    if (strcmp(subLabels{k}, 'N'))
        hsubLabels(k) = text(-0.23,1.17,'','Units', 'Normalized', 'VerticalAlignment', 'Top');
    else
        hsubLabels(k) = text(xpos,1.27,subLabels{k},'Units', 'Normalized', 'VerticalAlignment', 'Top');
    end 
 
    
        if ( strcmp(subTexts{k, 1} , 'None') )
            hTitles(k) = title('');
        else
            hTitles(k) = title(subTexts{k, 1});
        end
        if ( strcmp(subTexts{k, 2} , 'None') )
            hxLabels(k) = xlabel('');
        else
              hxLabels(k) = xlabel(subTexts{k, 2});
        end
        
        if ( strcmp(subTexts{k, 3} , 'None') )
            hyLabels(k) = ylabel('');
        else    
            hyLabels(k) = ylabel(subTexts{k, 3});
        end
%               k = k+1;
end
 
%%


%%
% Legend
 
 
% Other Labeling goes here
 
 
% Formatting lines
    % Line width should be from 1.5 to t
    
chil = get(hsubplots(FFTavg), 'children');
set (chil(1), ...
    'Color'         , co , ...
    'LineWidth'     , 1             );

chil = get(hsubplots(ecFFT), 'children');
try
    set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 1             );
catch
end

chil = get(hsubplots(autoCorr), 'children');
% set (chil(2), ...
%     'Color'         , co , ...
%     'LineWidth'     , 1             );
 
 
chil = get(hsubplots(olmFFT), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 1             );
 

 chil = get(hsubplots(firingR), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 0.5             );
try
chil = get(hsubplots(spikePlot), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 1             , ...
    'MarkerSize'    ,3             );
    
chil = get(hsubplots(bcFFT), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 1             );
end
try
chil = get(hsubplots(volt1), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 0.5             );
chil = get(hsubplots(volt2), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 0.5             );


chil = get(hsubplots(uavg1), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 1             );
 

chil = get(hsubplots(uavg2), 'children');
set (chil(2), ...
    'Color'         , co , ...
    'LineWidth'     , 1             );
 
catch exception
end
%%%%%%%%%%%%%%%%%%%%%%
% Formatting text    %
%%%%%%%%%%%%%%%%%%%%%%
    
        set( hsubplots                       , ...
        'FontName'   , 'Arial' );
        set([hTitles, hxLabels, hyLabels], ...
                'FontName'   , 'Arial');
    % Labels  
        set([ hyLabels, hxLabels]  , ...
            'FontSize'   , 8          );
 
    % Titles
        set( hTitles                   , ...
            'FontSize'   , 10           );
        
        set( hsubLabels                    , ...
            'FontSize'   , 10         , ...
            'FontWeight' , 'bold'      );
 
    % Smaller
        set([hsubplots]             , ...  % Legend goes here.
            'FontSize'   , 8           );
 
        try
             set([texters]             , ...  % Legend goes here.
            'FontSize'   , 8           );
        catch exception
        end
        
% Other formatting
axes(hsubplots(schem));
axis off

axes(hsubplots(FFTavg));
%     set(gca, 'YTick'       , 0:20:63);
set(gca, 'XMinorTick'  , 'on'      );
% axis tight        

if schematic == 2
    ylim([0 20]) ; 
    set(hyLabels(ecFFT), 'string', '') 
    set(hyLabels(olmFFT), 'position', [-12.1 -.35 1]) 
    set(hsubLabels(bcFFT), 'position', [-0.29 1.27 0])
    
    set(hsubLabels(dgFFT), 'position', [-0.29 1.27 0])
end
xlim([0  50]);
        
         set(gca, 'XTick'       , 0:10:50);
xoffset=-0.00;
yoffset=0.08;
tickvals=get(gca,'YTick')./10^3;
multi(1) = text(0-max(get(gca,'XTick'))*xoffset, ...
  (1+yoffset).*max(tickvals).*10^3, ...
  sprintf('x 10^3'),'FontSize', 8) ;

%         box on;
ymax = 1.0;
axes(hsubplots(olmFFT));
         set(gca, 'XTick'       , 0:10:50);  
         set(gca, 'XTickLabel',['  '; '10' ; '  '; '30'; '  '; '50'])
          set(gca, 'YTickLabel', ['0'; ' '; '1'; ' ']);
                 
         xlim([0 50]);
        ylim([0 ymax]);
        xoffset=-0.01;
yoffset=0.11;
tickvals=get(gca,'YTick')./10^3;
multi(1) = text(0-max(get(gca,'XTick'))*xoffset, ...
  (1+yoffset).*max(tickvals).*10^3, ...
  sprintf('x 10^3'),'FontSize', 8) ;
        box off;
   multi(1) = text(max(get(gca,'XTick'))*.6, ...
  (0.8).*max(tickvals).*10^3, ...
 'OLM' ,'FontSize', 8) ;     


axes(hsubplots(ecFFT));
        xlim([0 50]); ylim([0 ymax]);
          set(gca, 'YTickLabel', ['0'; ' '; '1'; ' ']);
                 set(gca, 'XTick'       , 0:10:50);
                 set(gca, 'XTickLabel',['  '; '10' ; '  '; '30'; '  '; '50'])
                      multi(1) = text(max(get(gca,'XTick'))*.6, ...
  (0.8).*max(tickvals).*10^3, ...
 'EC' ,'FontSize', 8) ;    

                 

axes(hsubplots(bcFFT));
        xlim([0 50]);
        ylim([0 ymax]);
                 set(gca, 'XTick'       , 0:10:50);
                  set(gca, 'YTickLabel','');
             set(gca, 'XTickLabel',['  '; '10' ; '  '; '30'; '  '; '50'])
                   box off
               multi(1) = text(max(get(gca,'XTick'))*.6, ...
  (0.8).*max(tickvals).*10^3, ...
 'BC' ,'FontSize', 8) ;     


axes(hsubplots(dgFFT));
        xlim([0 50]);
%         ylim([0 0.5]);
                 set(gca, 'XTick'       , 0:10:50);
                  set(gca, 'YTickLabel','');
             set(gca, 'XTickLabel',['  '; '10' ; '  '; '30'; '  '; '50'])
                   box off
               multi(1) = text(30, 7.6, 'DG' ,'FontSize', 8) ;     

    
axes(hsubplots(firingR));

xlim([0 3000])
xoffset=-0.02;
yoffset=-0.01;
tickvals=get(gca,'YTick')./10^3;

multi(1) = text(0-max(get(gca,'XTick'))*xoffset, ...
  (1+yoffset).*max(tickvals).*10^3, ...
  sprintf('x 10^3'),'FontSize', 8) ;
     box off

axes(hsubplots(spikePlot));
        xlim([0 3000])
        set(gca, 'YTick'       , 0:20:63);
        ylim([1 63]);
%         set(gca, 'XTickMode','manual')
%         set(gca, 'XTickLabel',[]) 
axes(hsubplots(volt1));
     box off;
     xlim([0 3000]);
     ylim([-100 40]);
     set(gca, 'YTick'       , [-80 -20 40], 'XTick', 0:1000:3000);
     set(gca, 'XTickLabel',[]) 
     set(gca, 'XTickMode','manual')
     set(hsubLabels(volt1), 'position', [-0.22 1.4 0])

axes(hsubplots(volt2));
     box off;
     xlim([0 3000]);
     ylim([-100 40]);
     set(gca, 'YTick'       , [-80 -20 40], 'XTick', 0:1000:3000);
     set(gca, 'XTickMode','manual')
     set(hsubLabels(volt2), 'position', [-0.22 1.4 0])
%%
if schematic == 16
   axes(hsubplots(FFTavg))
   set(hyLabels(FFTavg), 'position', [-12.93 0.355 1])
   axes(hsubplots(FFTavg2))
   ylim([0 1.5])
   xlim([0  50]);
   set(gca, 'XTick'       , 0:10:50);
   
   axes(hsubplots(uavg1))
   box off
    ylim([ 0.049 0.11])
    xlim([-10 300]); set(gca, 'XTick'       , 0:100:400 ); 
    xlabel('Time after spike (ms)'); ylabel('u (uA)')
   
   axes(hsubplots(uavg2))
        box off
        ylim([ 0.035 0.1])
        xlim([-10 300]); set(gca, 'XTick'       , 0:100:400 ); 
        xlabel('Time after spike (ms)'); 
   
    axes(hsubplots(isi1))
    chil = get(gca, 'children');
    set (chil(2), ...
        'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
    xlim([-10 300]); set(gca, 'XTick'       , 0:100:300 );
    ylim([0 6])
    box off
   
    axes(hsubplots(isi2))
    chil = get(gca, 'children');
    set (chil(2), ...
        'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
    xlim([-10 300]); set(gca, 'XTick'       , 0:100:300 );
    ylim([0 12])
    box off
   
end
%%     
%%
if schematic == 18
   axes(hsubplots(FFTavg))
   set(hyLabels(FFTavg), 'position', [-12.93 0.355 1])
   axes(hsubplots(FFTavg2))
   ylim([0 1])
   xlim([0  50]);
   set(gca, 'XTick'       , 0:10:50);
   
   axes(hsubplots(FFTavg2))
   ylim([0 1])
   xlim([0  50]);
   set(gca, 'XTick'       , 0:10:50);
   
end
%%
set(hsubplots, ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'LineWidth'   , 1         );
if schematic == 16; set(hsubplots([FFTavg, FFTavg2, uavg1, uavg2, isi1, isi2]), ...
  'TickLength'  , [.04 .04]); end
if schematic == 2; set(hsubplots([olmFFT, bcFFT, ecFFT, dgFFT]), 'TickLength'  , [.04 .04]); end
        
 
%   'YTick'       , 0:500:2500, ...
%'Box'         , 'off'     , ...
if  plotSize == 1
annotateFunc( schematic,[0.15 0.73 0.28286624203822 0.18075837742504] )
end; if plotSize == 2
annotateFunc( schematic,[0.120987 ysch 0.28286624203822 0.32] )
end; if plotSize == 3   
figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [18 4 17.4  10])
end; 
 
 
 

if plotSize == 4
    if schematic == 7
    annotateFunc( schematic,[0.01 0.11 0.12 0.6] ); end;
    if schematic == 5
    annotateFunc( schematic,[0.029 0.2 0.15 0.62] ); end;
end
if plotSize == 5
    if schematic == 16
    annotateFunc( schematic,[0.06 0.3 0.15 0.46] ); 
    else
            if schematic == 18
    annotateFunc( 16,[0.06 0.3 0.15 0.46] ); 
            else
        annotateFunc( schematic,[0.065 0.25 0.15 0.46] ); end;
    end
end;
    if schematic == 18
    annotateFunc( 16,[0.06 0.3 0.15 0.46] ); 
    end
% previous x pos 0.76 0.14
%% Last minute touches
if plotSize == 4

set(hsubLabels(FFTavg), 'Position', [ -0.43    1.27         0 ])
set(hyLabels(FFTavg), 'units', 'normalized')
set(hyLabels(FFTavg), 'position', [ -0.2088    0.5000         0])

end;

% export_fig ./Images/Fig5.tif -r600

% export_fig ./Images/BC.tif -r300 -nocrop % Anotate
%annotateFunc( schematic,[0.25 0.3 0.48286624203822 0.48075837742504] )
% excmd = ['export_fig ./Images/final' num2str(schematic) '.tif -r600 -nocrop'];
% eval(excmd)
 
