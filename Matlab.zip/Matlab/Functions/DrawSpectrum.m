function [ output_args ] = DrawSpectrum(i, OutPath, expSig, tstop, windowLen, handAxis)
% Draws the spectrum given the i of the cells and where the files are
%   Detailed explanation goes here

 cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];


fileNames = dir([OutPath expSig 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
 
 cxxs = [];
pxxs = []; 
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);
 
    ev = zeros(1, tstop);
    rSPT = round(SpikeTimes(:,2));
    for ST = 1:length(rSPT)
       try
        ev(rSPT(ST)) = ev(rSPT(ST)) + 1; 
       catch me
       end
    end
 
    [f,Pxxn,tvect,Cxx] = psautospk(ev, 1, windowLen, bartlett(windowLen), windowLen/2, 'none') ;
 
    pxxs(:,end+1) = Pxxn;
    cxxs(:, end+1)= Cxx;
 
end
 
xx = 0:size(pxxs,1)-1;
yy = mean(pxxs,2);
sy = std(pxxs');
 
axes(handAxis)
% hsubplots(ecFFT) = subplot (yplots,xplots, ecFFT); % second subplot
rr = 1000;
hold on
boundedline(xx', yy/rr, sy/rr, 'k')


end

