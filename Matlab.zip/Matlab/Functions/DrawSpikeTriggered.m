function [u, isi, newaxis, labelHand] = DrawSpikeTriggered(i, preArea, OutPath, expSig, input, seeds, exper, ACHvals,  tstop, windowLen, handAxis1, handAxis2)
% Draw the spike-triggered average of the adaptation current u, and the ISI distribution
%   Decreased the analysis period to 1000 ms

i = 2;
cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];



postArea = 2 -1;


fileNames = dir([OutPath '*' expSig 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
k = 0; is= [];fr = [];

% compile the file name
% expSig3d = expSig3d(2:end)

grandu = struct(); % To store values across runs
grandv = struct(); % To store values across runs
grandISI = struct() ;
grandc = struct() ;

TimeWindow = 400;

for ai = 1:length(ACHvals)
    for ii = 1:length(input)
        pxxSeed = [];
        seedu = struct(); seedv= struct(); %Used to collect data over seeds

% resets here so that it gathers information from all seeds        
            dist = struct(); 
            stmean = struct();
            utData = struct();

        for si = 1:length(seeds)
            
            Basename = [ num2str(input(ii)) '-' num2str(seeds(si)) '-' num2str(exper) '-' num2str(ACHvals(ai)) expSig];
            name = [Basename 'SpikeTime' num2str(areaCode(i)) '.txt'];
            if exist([OutPath name], 'file')
                disp(name);
                SpikeTimes = importdata([OutPath name]);
                if (~isempty(SpikeTimes))
                nID = unique( SpikeTimes(:,1) ); nID( nID == 62 ) = [];

%% Spike times loaded for this simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     fr(end+1) = length(SpikeTimes)/(63*30)
%% ISI    
for kk = 1:length(nID)
    Spikes = SpikeTimes( SpikeTimes(:,1)== nID(kk) ,2);
    if (~isempty(Spikes))
        for sp = 1:length(Spikes)
            if (Spikes(sp) < tstop-TimeWindow) % Discard the last TimeWIndow spikes
                diff = Spikes-Spikes(sp);
                ISIs = diff( diff>0 & diff<TimeWindow);
                if (~isempty(ISIs))
                %%% Keeep only the NEXT spike
                minISIs = min(ISIs);
    %             minISIs = (ISIs);
                            dist(end+1).nn = minISIs;
%                 else
%                     dist(end+1).nn = 0;
                end
            end
        end
    end % if spike empty
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    ConName = [Basename 'Connections.txt'];
                    CurName = [Basename 'Currents.txt'];

                    
                    
                    if (exist([OutPath ConName], 'file') &&  exist([OutPath CurName], 'file') )
                        disp('Found currents and connections');
                        
                        currents = importdata([OutPath CurName]);
                        con = importdata([OutPath ConName]);

%% currents and cons loaded for this  simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                      

pop_con = con ( con(:, 2) == preArea & con(:,4) == postArea, :); % Getting the currents matching the desired populations


for kk = 1:length(nID)
    Spikes = SpikeTimes( SpikeTimes(:,1)== nID(kk) ,2);

    neuron_con = pop_con ( pop_con(:, 5) == kk, :);
    cID = neuron_con(:,1); % THe unique IDs of con incoming to kk neuron

    % Find the col index for these unique current IDs
    [c, present2, cIDi] = intersect(currents(1,:), cID);
    values = currents(:, present2);
    
    tvec = currents(:, 1);
    
    for sp = 1:length(Spikes)
        if (Spikes(sp) < tstop-TimeWindow) % Discard the last TimeWIndow spikes
            CorrectTimes = (  (tvec>Spikes(sp) & tvec<Spikes(sp)+TimeWindow)) ;
            valuesOne = values; % CHANGE FROM U AND VOLTS (2:end, values(1,:) == nID(kk) ) ;
            if (~isempty(valuesOne))
                Filtered = valuesOne(  CorrectTimes, : ); %Taking the vals withing timeWindow
                mf = mean(Filtered, 2);
                stmean(end+1).nn = mf(1:TimeWindow-1); %Using ms to number values as the sampling freq is 1 sample per 1 ms
            end
        end
    end
end


smo = smooth(mean([stmean.nn], 2));
grandc(ii, ai, si).nn = smo;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                        
                    end

                    
                    
                    VoltName = [Basename 'Volts.txt'];
                    UoltName = [Basename 'Uolts.txt'];
                    if (exist([OutPath VoltName], 'file') &&  exist([OutPath UoltName], 'file') )
                        disp('\nFound u and v')
                        
                        Volts = importdata([OutPath VoltName]);
                        Uolts = importdata([OutPath UoltName]);


%% Voltage and u loaded for this  simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                      

%% recovery current U

utData = struct(); % To store values for one run

tvec = Uolts(2:end, 1);
values = Uolts(:, :);

for kk = 1:length(nID)
    Spikes = SpikeTimes( SpikeTimes(:,1)== nID(kk) ,2);
    
    
        Spikes = Spikes ( Spikes(:) < 1000);
  disp(['u neuron ' num2str(kk)])  
   
  
  
  for sp = 1:length(Spikes)
        if (Spikes(sp) < tstop-TimeWindow) % Discard the last TimeWIndow spikes
            CorrectTimes = (  (tvec>Spikes(sp) & tvec<Spikes(sp)+TimeWindow)) ;
            valuesOne = values(2:end, values(1,:) == nID(kk) ) ;
            Filtered = valuesOne(  CorrectTimes, : ); %Taking the vals withing timeWindow
            mf = mean(Filtered, 2);
            utData(end+1).nn = mf;
        end
    end
end

grandu(ii, ai).nn = mean([utData.nn], 2);


%% recovery current U

vtData = struct(); % To store values for one run

tvec = Volts(2:end, 1);
values = Volts(:, :);

for kk = 1:length(nID)
    Spikes = SpikeTimes( SpikeTimes(:,1)== nID(kk) ,2);

    
            Spikes = Spikes ( Spikes(:) < 1000);
  disp(['v neuron ' num2str(kk)])  

    
    for sp = 1:length(Spikes)
        if (Spikes(sp) < tstop-TimeWindow) % Discard the last TimeWIndow spikes
            CorrectTimes = (  (tvec>Spikes(sp) & tvec<Spikes(sp)+TimeWindow)) ;
            valuesOne = values(2:end, values(1,:) == nID(kk) ) ;
            Filtered = valuesOne(  CorrectTimes, : ); %Taking the vals withing timeWindow
            mf = mean(Filtered, 2);
            vtData(end+1).nn = mf;
        end
    end
end


grandv(ii, ai).nn = mean([vtData.nn], 2);                    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    end voltage current                    
                    
                    end
                        
                        
                        
                        
                        
                    
                    
                end
            end
        end
        grandISI(ii, ai).nn = [dist(:).nn];
% If nn has more than one element you'll have to use:
    % ISIvec = [];
    % for jj =1:size(dist, 2)
    %     ISIvec = [ISIvec; dist(jj).nn];  end

    end
end
%%
% figure('Color', [1 1 1], 'Units', 'centimeters', 'Position', [24.5 6 13 11.5]) %15 11]); % one column 8.3 1.5 column 12.35 cm two columns 17.35 cm


hsubplots2(1) = (handAxis1);
axes(handAxis1)

if (length(grandu) >= 1)  % This check does not work, it has to be set to >=1
    
    plot(0:1:TimeWindow-2, grandu(1,1).nn(1:10:(TimeWindow-1)*10), 'color', [0.9 0.2 0.2], 'linestyle', '--',     'LineWidth'     , 1);
u = grandu(1,1).nn(1:10:(TimeWindow-1)*10); % send to outputs

axis tight
    xlim([-10 400]); set(gca, 'XTick'       , 0:100:400 );
else ; u  = 0; end %Silly line just to ensure assiging u output
    hold on
if (length(grandc) >= 1)

    % Getting all the seeds info
            grc = ( [grandc(:).nn] );
            mgrc = mean(grc, 2);
        newaxis = addaxis( 0:1:TimeWindow-2, mgrc);
        ylim([0.0014 0.002])
  box off       
            

%     addaxis( 0:1:TimeWindow-2, grandc(1,2).nn , 'r')


%     newaxis = addaxis( 0:1:TimeWindow-2, grandc(1,1).nn)
    labelHand = addaxislabel(2,'Current (uA)');
    hold on
end    % plot(newaxis, 0:1:TimeWindow-2, grandu(1,2).nn(1:10:(TimeWindow-1)*10))
    %  addaxisplot(0:1:TimeWindow-2, grandu(1,2).nn(1:10:(TimeWindow-1)*10), 'g');
    axis tight
    xlim([-10 400]); set(gca, 'XTick'       , 100:200:400 ); 

xlabel('Time after spike (ms)'); ylabel('u')

% subplot(2,2,2)
% plot(0:1:TimeWindow-2, grandu(1,1).nn(1:10:(TimeWindow-1)*10));
% hold on
% if (length(grandu) > 1)
% plot(0:1:TimeWindow-2, grandu(1,2).nn(1:10:(TimeWindow-1)*10), 'r');
% end

hsubplots2(2) = (handAxis2);
axes(handAxis2);

[counts, binValues] = hist(grandISI(1,1).nn, 100); 
NormalizedCounts = 100*counts/ sum(counts);
bar(binValues, NormalizedCounts, 'barwidth', 1)


isi = grandISI(1,1).nn; %% send to output
chil = get(gca, 'children');
% set (chil(1), ...
%     'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
xlabel('ISI (ms)'); ylabel('Count');
xlim([-10 400]); set(gca, 'XTick'       , 0:100:400 );
box off
hold on
if (length(grandISI) > 1)
    subplot(2,2,4)
    hist(grandISI(1,2).nn, 100, 'r')
end


% set(gcf, 'Position', [24.5 6 13 7.5]);
% figure
% windowLen = 200;
% [f,Pxxn,~,Cxx] = psautospk(grandc.nn, 1, windowLen, bartlett(windowLen), windowLen/2, 'none') ;
% plot(Pxxn)
% xlim([0 50])

set(hsubplots2, ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.3 .3 .3], ...
  'YColor'      , [.3 .3 .3], ...
  'LineWidth'   , 1         );


end

