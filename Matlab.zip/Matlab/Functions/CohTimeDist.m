function [] = CohTimeDist ( i, OutPath, expSig, input, seeds, exper, ACHvals, twindow, tstop, SpikeTimes )
% Returns coherence by time window, as a singluar value
%  and also broken down by distance
%   Locations are taken from one set of data on this device

set(gcf, 'Position', get(gcf, 'Position') + [0 0 4 0])

axes(hsubplots(autoCorr));
%         xlabel('Recurrent connection weight')
%         ylabel('Network Freq.(Hz)')
texters (1) = text( 0.491, 0.96, {'Control'}, 'Units', 'Normalized')        ;
texters (2) = text( 00.1822  ,  0.1926 , {'No', 'depression'}, 'Units', 'Normalized');

%     Loc = importdata([OutPath 'Loc0' num2str(areaCode(i)) '.txt']);
   Loc = importdata(['..\..\Outputs3\Quant\LastPush\' '/50-0-6-1ECFinalLoc0' num2str(areaCode(i)) '.txt']);

fileNames = dir(['..\..\Outputs3\Quant\LastPush\' expSig 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
distances = []; mean_cohs = [];
for sname = fn
    SpikeTimes = importdata([OutPath sname{1}]);

    dist = @(from, to) [abs(Loc(from+1,1) - Loc(to+1,1))];
    dist(0,6)

    distCoh = [];
    for ii = 0:cellNumbers(i)-2
        for jj = ii +1:cellNumbers(i)-2
            distCoh(end+1, 1) = dist(ii,jj);
            distCoh(end, 2) = CoherenceXY(ii,jj, twindow, tstop, SpikeTimes);
        end
    end
    distCoh(:,1) = round(distCoh(:,1) * 100)/100;
    uniDist = unique(distCoh(:,1));

    dmc = [];
    for dd = 1:length(uniDist)
        specDistCoh = distCoh ( distCoh(:,1) == uniDist(dd), :);
        meanC = mean(specDistCoh(:,2));
        stdC = std(specDistCoh(:,2));
        dmc(end+1, :) = [uniDist(dd), meanC, stdC];
    end
    distances = [distances dmc(:,1)];
    mean_cohs = [mean_cohs dmc(:,2)];


end

