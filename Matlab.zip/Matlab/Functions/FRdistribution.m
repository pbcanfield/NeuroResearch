function [ ] = FRdistribution( i, OutPath, expSig, input, seeds, exper, ACHvals,  tstop, windowLen, handAxis )
% Calculates and draws the firing rate distribution for a few seeds
%   Detailed explanation goes here

 cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];


expSigFR = [num2str(input) '-*-' num2str(exper) '-' num2str(ACHvals) expSig];

fileNames = dir([OutPath expSigFR 'SpikeTime' num2str(areaCode(i)) '.txt' ]);
fn = {fileNames.name};
spikes=[]; indNeurons = struct();
allNeurons = struct();
 
% for sname = fn %% count only one seed
sname = fn(1); 
    SpikeTimes = importdata([OutPath sname{1}]);
% sname{1}

% if (ExcludeFirst500 == 1)   %Eclude first 500 ms 
%     tstop = 20000; 
    SpikeTimes = SpikeTimes( SpikeTimes(:,2)>500, : ); 
    SpikeTimes  = [SpikeTimes(:,1), SpikeTimes(:,2)-500];
% end

    allNeurons(end+1).times = SpikeTimes( :,2)/1000; % Gatherting data for Chronux

 nID = unique(SpikeTimes(:,1));
%    nID = 1:max(nID);
    for jj = 1:length(nID)
        spiketimes = SpikeTimes( SpikeTimes(:,1) == nID(jj), 2);

        indNeurons(end+1).times= spiketimes /1000; % Gatherting data for Chronux
   
        spikes(end+1) = length(spiketimes);
    end
% end %% count only one seed

spikes = (spikes/(tstop/1000));
mean(spikes)
axes(handAxis)
hold off 

c_min = -0.3;
c_max = 1.8;
edges = 10.^(c_min:0.1:c_max); 
edges(1) = 0; % to include neurons that spike 0 or very few spikes.
h = histc(spikes, edges);
centers = sqrt(edges(1:end-1).*edges(2:end));
normalized_h = h./sum(h);
barhandle = bar(normalized_h.* 100);
% ylim([0 40]) 

% # fix the x-labels, x-axis extents
% xlim([0.5,length(centers)+0.5])
% set(gca,'xticklabel',num2str(centers(:),'%5.2f'))
xlim([0.5,length(centers)-2+0.5]); set(gca, 'xtick', [1: length(centers)+1]) 
set(gca,'xticklabel',num2str(centers(:),'%1.1f'))

% Relabiling
ni = 0:20;% max(xlim);
% ni = ni + 0.5;
ti = log10(ni);
ti = ti * (18/max(ti));
set(gca, 'xtick', ti)
set(gca, 'xticklabels', ni)
set(gca, 'tickdir', 'out')

set(gca, 'xticklabels', ['  '; '  '; ' 1'; '  '; '  '; '  '; ' 5' ; '  '; '  '; '  '; '  '; '10'; '  '; '  '; '  '; '  '; '15'; '  '; '  '; '  '; '  '; '  '])
box off
 set(barhandle, 'FaceColor',[0.501960813999176 0.501960813999176 0.501960813999176]);
% xlabel('Rate (Hz)')
% ylabel('%')
%  ylim([0 12])
% axis tight
end %firing rate dist



