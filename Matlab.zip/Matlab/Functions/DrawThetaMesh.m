function [coh, SpikeCount] = DrawThetaMesh(OutPath, expSig, input, ACHvals, seeds, expType , tstop)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%%% 
i = 2;
 cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];

not_found = 0;
fileNames = dir([OutPath '*' expSig  'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
SpikeCount = zeros(length(ACHvals), length(input));
coh = zeros(length(ACHvals), length(input));
% compile the file name
% expSig = expSig(2:end)
for ai = 1:length(ACHvals)
    for ii = 1:length(input)
        for si = 1:length(seeds)
        name = [ num2str(input(ii)) '-' num2str(seeds(si)) '-' num2str(expType) '-' num2str(ACHvals(ai)) expSig 'SpikeTime' num2str(areaCode(i)) '.txt'];   
%         name = [ num2str(input(ii)) '-' num2str(seeds(si)) '-' num2str(ACHvals(ai)) '-' num2str(expType)  expSig 'SpikeTime' num2str(areaCode(i)) '.txt'];
        if ismember(name, fn)
           disp(name); 
              SpikeTimes = importdata([OutPath name]);
              if (~isempty(SpikeTimes))
%                 coh(ai, ii) |= mean(CoherenceXY(pairs(:,1), pairs(:,2), twindow, tstop, SpikeTimes));
   ev = zeros(1, tstop);
    rSPT = round(SpikeTimes(:,2));
    for ST = 1:length(rSPT)
       ev(rSPT(ST)) = ev(rSPT(ST)) + 1; 
    end
 tstop = 3000; 
windowLen = 1024;
[f,Pxxn,tvect,Cxx] = psautospk(ev, 1, windowLen, bartlett(windowLen), windowLen/2, 'none') ;
% w =max(Pxxn)/Pxxn(1);
% if w>300
% coh(ai, ii) = 300
% else
%     coh(ai, ii) = w;
% end
% coh(ai, ii) = mean(Pxxn(4:12))/mean(Pxxn);
SpikeCount(ai, ii, si) = length( SpikeTimes);
coh(ai, ii, si) = sum(Pxxn(4:12))/sum(Pxxn(1:50) );
% [u, coh(ai, ii, si) ] = max(Pxxn(1:12));
              else
                coh(ai, ii, si) = 0;
              end 
        else
            not_found = not_found + 1;
            disp([num2str(ai) '  ' num2str(ii)]);
            disp([name])
        end
        
        end
    end
end


egray = 1:-1/63:0;
egray = egray';
igray  = [egray egray egray];
% 
% %% write to a file and load it instead
% 
Meancoh = mean(coh, 3);
% dlmwrite('cohRCoff.txt', Meancoh);
% % Meancoh = importdata('coh.txt' );

% surf(col)
% colormap(igray)
% pcolor(ACHvals, [lo:5:li], Meancoh')
% hcb = colorbar();

% set( labcb, 'FontSize', 8)
%%
% Con = importdata('cohCon.txt' );
% OLMoff = importdata('cohOLMoff.txt');
% RCoff = importdata('cohRCoff.txt');

% hsubplots(10)=subplot(yplots, xplots, 10);
if (size(Meancoh, 2) > 1)
pcolor(ACHvals, input, Meancoh')
end
hcb(1) = colorbar('Location', 'SouthOutside');

end