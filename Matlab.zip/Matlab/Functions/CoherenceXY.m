function [ coh ] = CoherenceXY( x, y, twindow, tstop, SpikeTimes)
%CoherenceXY calculates the Wang Buzsaki coherence function for a pair of
%neurons given their spike times
%   x, y: are the spike times of neuron x and y respectively
%   twindow is the time window to consider two spikes as coherent
%  time = size(NS,2) * dt;
%       twindow = 0.1 * (1 / (mean(sum(NS,2)) / time));
coh = 0;
cohSum = 0;

        
if (nargin > 4 && length(x) > 1)
    for ii = 1:length(x)
    coh(ii) = CoherenceXY(x(ii), y(ii), twindow, tstop, SpikeTimes);    
    end
    
else

    if (nargin >4)
        x = SpikeTimes(SpikeTimes(:,1) == x, 2);
        y = SpikeTimes(SpikeTimes(:,1) == y, 2);
    end

      if (twindow == 0)
         time = tstop / 1000;% Time in seconds
         firing_rate = (length(x) + length(y)) / 2 /time; %firing rate in Hz
         twindow = (0.1 / firing_rate) * 1000; %window in ms.

        if twindow < 3 ; twindow = 3; end
        if twindow < 10 ; twindow = 10; end
      end 
      
    for k = 1:length(x)
       cohSum = cohSum + sum(abs(x(k) - y) <= twindow);
    end
    if (length(x) * length(y) > 0)
        coh = cohSum/ sqrt( length(x) * length(y) );
    else
        coh = 0;
    end
end

end

