function [isi] = DrawSpikeTriggeredISIversion(i, preArea, OutPath, expSig, input, seeds, exper, ACHvals,  tstop, ExcludeFirst500, windowLen, handAxis1, handAxis2)
% Draw the spike-triggered average of the adaptation current u, and the ISI distribution
%   Detailed explanation goes here

% i = 2;
cellNumbers = [30 63 8 8 384 20 20];
areaCode = [0 1 2 3 4 7 8];



postArea = 2 -1;


fileNames = dir([OutPath '*' expSig 'SpikeTime' num2str(areaCode(i)) '.txt']);
fn = {fileNames.name};
k = 0; is= [];fr = [];

% compile the file name
% expSig3d = expSig3d(2:end)

grandu = struct(); % To store values across runs
grandv = struct(); % To store values across runs
grandISI = struct() ;
grandc = struct() ;

TimeWindow = 400;

for ai = 1:length(ACHvals)
    for ii = 1:length(input)
        pxxSeed = [];
        seedu = struct(); seedv= struct(); %Used to collect data over seeds

% resets here so that it gathers information from all seeds        
            dist = struct(); 
            stmean = struct();
            utData = struct();

        for si = 1:length(seeds)
            
            Basename = [ num2str(input(ii)) '-' num2str(seeds(si)) '-' num2str(exper) '-' num2str(ACHvals(ai)) expSig];
            name = [Basename 'SpikeTime' num2str(areaCode(i)) '.txt'];
            if exist([OutPath name], 'file')
                disp(name);
                SpikeTimes = importdata([OutPath name]);
                if (~isempty(SpikeTimes))
                nID = unique( SpikeTimes(:,1) ); nID( nID == 62 ) = [];

                
if (ExcludeFirst500 == 1)
     
    SpikeTimes = SpikeTimes( SpikeTimes(:,2)>500, : ); 
    SpikeTimes  = [SpikeTimes(:,1), SpikeTimes(:,2)-500];
    tstop = max( SpikeTimes(:,2) );
end

%% Spike times loaded for this simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     fr(end+1) = length(SpikeTimes)/(63*30)
%% ISI    
for kk = 1:length(nID)
    Spikes = SpikeTimes( SpikeTimes(:,1)== nID(kk) ,2);
    if (~isempty(Spikes))
        
        for sp = 1:length(Spikes)
            if (Spikes(sp) < tstop-TimeWindow) % Discard the last TimeWIndow spikes
                diff = Spikes-Spikes(sp);
                ISIs = diff( diff>0 & diff<TimeWindow);
                if (~isempty(ISIs))
                %%% Keeep only the NEXT spike
                minISIs = min(ISIs);
    %             minISIs = (ISIs);
                            dist(end+1).nn = minISIs;
%                 else
%                     dist(end+1).nn = 0;
                end
            end
        end
        
    end % if spikes empty
end




                        
                        
                        
                        
                        
                    
                    
                end
            end
        end
    if (length(dist)> 1)
                grandISI(ii, ai).nn = [dist(:).nn];
    end
                % If nn has more than one element you'll have to use:
    % ISIvec = [];
    % for jj =1:size(dist, 2)
    %     ISIvec = [ISIvec; dist(jj).nn];  end

    end
end

%     if (length(grandISI)> 1)
isi = grandISI(1,1).nn; %% send to output
%     else
%         isi = 1;
%     end
%%



