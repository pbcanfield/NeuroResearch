python seed_sweep.py 1200 0 simulation_config.json &
python seed_sweep.py 1201 0 simulation_config.json &
python seed_sweep.py 5001 0 simulation_config.json &
python seed_sweep.py 6001 0 simulation_config.json &
python seed_sweep.py 7001 0 simulation_config.json &
python seed_sweep.py 9001 0 simulation_config.json &
python seed_sweep.py 10001 0 simulation_config.json &
