import neuron
from neuron import h
import numpy as np
import pandas as pd
import sys
import random
  
def generate_noise(start,noise,number,interval,cells=1,tstop=100,cell_id_offset=0):
    TSTOP = tstop
    h("objref nil");
    
    netstims = []    
    netcons = []
    stims = []

    for i in range(cells[1]-cells[0]):
        netstims.append(h.NetStim())
        netstims[i].start = start
        netstims[i].noise = noise
        netstims[i].number   = number 
        netstims[i].interval = interval

        netcons.append(h.NetCon(netstims[i], h.nil))
        stims.append(h.Vector())
        netcons[i].record(stims[i])

    h.finitialize()
    neuron.run(TSTOP)

    ret = None

    for i in range(cells[0],cells[1]):
        spikes = stims[i-cells[0]]
        spikes = np.array(spikes).reshape(-1,1)
        ids = (np.ones(len(spikes))*i+cell_id_offset).astype(int).reshape(-1,1)
        sid = np.concatenate((ids,spikes),axis=1)
        pdsid = pd.DataFrame(sid,columns=['node_ids','timestamps'])

        if ret is None:
            ret = pdsid
        else:
            ret = ret.append(pdsid, ignore_index=True)

    ret = ret.sort_values(by="timestamps")[["timestamps","node_ids"]]
    ret.node_ids = ret.node_ids.astype(int)
    return ret


def gen_exp0_noise(seed=479,tstop=10000):

    random.seed(seed)

    offset = 1034
    
    #CA3 virt
    population = "exp0input"
    start = 0
    noise = 1
    number = 1e100
    interval = 1000.0/1.0
    cells = [20,83]
    stims = generate_noise(start,noise,number,interval,cells=cells,tstop=tstop)
    stims['population'] = population
    stims.to_csv('input/exp0_ca3_noise.csv',index=False,sep=' ')

    #DG virt
    population = "exp0input"
    start = 0
    noise = 1
    number = 1e100
    interval = 1000/3.0
    cells = [84,468]
    stims = generate_noise(start,noise,number,interval,cells=cells,tstop=tstop)
    stims['population'] = population
    stims.to_csv('input/exp0_dg_noise.csv',index=False,sep=' ')


if __name__ == '__main__':

    """
    # To verify that you get the correct frequency of input:
    
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv('input/exp0_dg_noise.csv',sep=' ')
    tstop = 10000
    num_sec = tstop/1000
    df['node_ids'].value_counts().mean()/num_sec
    # 3.206611570247934
    plt.scatter(df['timestamps'],df['node_ids'])
    # <matplotlib.collections.PathCollection object at 0x0000013C776E1288>
    plt.show()

    """

    if len(sys.argv) == 2:
        gen_exp0_noise(int(sys.argv[1]))
    else:
        gen_exp0_noise()

