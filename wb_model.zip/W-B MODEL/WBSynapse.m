alph=12; beta=0.1;
Tmax=0.1;Cdur=1;
alphaTmax = alpha*Tmax;
alphaTmaxplusBeta=alpha*Tmax + beta;
t=0;dt=0.05;tmax=150;
r=zeros(1,tmax/dt);
while t<=tmax,
    t=t+dt;
if t<Cdur
r(round(t/dt))=(alphaTmax/alphaTmaxplusBeta)*(1-exp(-t*alphaTmaxplusBeta));
elseif t>Cdur 
    r(round(t/dt))=r(Cdur)*exp((-t-Cdur)/beta);
end
 
end
gsyn=0.1; Esyn=-75;
i_syn=gsyn*r*10;