These are just variations of the conn.dat file, to include various combinations of gap junctions, recurrent axons, basket cell connections.
The "inline gaps" from the 2009 paper are in connlineargaps.dat
The gaps between basket cells from the supplemental figure are connwithbaskgaps.dat
The highly branched recurrent axons are conn10sprouts.dat

For the inline gaps and rec axon simulations, the figures were generated with a bask-pyr AMPA conductance of 0, 
so although these files show the connections intact, there was no basket cell feedback for the figures stating basket cells were "off".
