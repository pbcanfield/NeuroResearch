#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _k_rtm_reg(void);
extern void _k_wb_reg(void);
extern void _leak_reg(void);
extern void _na_rtm_reg(void);
extern void _na_wb_reg(void);
extern void _syngrad_reg(void);
extern void _vecevent_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," \"./k_rtm.mod\"");
    fprintf(stderr," \"./k_wb.mod\"");
    fprintf(stderr," \"./leak.mod\"");
    fprintf(stderr," \"./na_rtm.mod\"");
    fprintf(stderr," \"./na_wb.mod\"");
    fprintf(stderr," \"./syngrad.mod\"");
    fprintf(stderr," \"./vecevent.mod\"");
    fprintf(stderr, "\n");
  }
  _k_rtm_reg();
  _k_wb_reg();
  _leak_reg();
  _na_rtm_reg();
  _na_wb_reg();
  _syngrad_reg();
  _vecevent_reg();
}
